-- Display-only observer for the original ADAS+ ZIP. No debug/private upvalue APIs.
local M={}
local now,sendTimer,hookTimer=0,0,0
local acc,fcm,lane,utils
local active=false
local accSeen,frontSeen,warningUntil=-100,-100,-100
local hooks={}
local hooked=false
local function hookMember(t,k,make)
 if type(t)~='table' or type(t[k])~='function' then return false end
 local old=t[k];local wrap=make(old);t[k]=wrap
 hooks[#hooks+1]=function()if t[k]==wrap then t[k]=old end end
 return true
end
local function rememberFront(data)
 if type(data)~='table' then return end
 for _,index in ipairs({2,3}) do
  if type(data[index])=='table' then
   for _,v in pairs(data[index])do
    if type(v)=='table' and v.other_veh and type(v.distance)=='number' and v.distance>=0 and v.distance<9999 then frontSeen=now;return end
   end
  end
 end
end
local function install()
 if not rawget(_G,'scripts_driver__assistance__angelo234_extension') then return end
 local ok=pcall(function()
  acc=require('scripts/driver_assistance_angelo234/accSystem')
  fcm=require('scripts/driver_assistance_angelo234/forwardCollisionMitigationSystem')
  lane=require('scripts/driver_assistance_angelo234/laneCenteringAssistSystem')
  utils=require('scripts/driver_assistance_angelo234/extraUtils')
 end)
 if not ok or type(acc)~='table' or type(fcm)~='table' or type(lane)~='table' then return end
 hookMember(acc,'onToggled',function(old)return function(on,...)
  active=on==true;return old(on,...)
 end end)
 hookMember(acc,'update',function(old)return function(dt,veh,params,aeb,data,...)
  active=true;accSeen=now;rememberFront(data);return old(dt,veh,params,aeb,data,...)
 end end)
 hookMember(fcm,'update',function(old)return function(dt,veh,params,aeb,beep,data,...)
  rememberFront(data);return old(dt,veh,params,aeb,beep,data,...)
 end end)
 hooked=true
 if log then log('I','bmwF10Bridge','Public module observers installed; no private/debug API') end
end
local function update(dt)
 now=now+math.max(0,dt or 0);sendTimer=sendTimer+(dt or 0);hookTimer=hookTimer+(dt or 0)
 if not hooked and hookTimer>=1 then hookTimer=0;install() end
 if not hooked or sendTimer<0.1 then return end;sendTimer=0
 local veh=be:getPlayerVehicle(0);if not veh then return end
 local target=acc.getCurrentTargetSpeed and acc.getCurrentTargetSpeed() or nil
 local accOn=active and now-accSeen<0.5
 local hardware=utils.getPart('acc_angelo234')
 hardware=hardware~=nil and hardware~=false
 local values=rawget(_G,'electrics_values_angelo234')
 -- ADAS+ alternates JSON text and decoded tables during its GE exchange.
 if type(values)=='string' and type(jsonDecode)=='function' then
  local ok,decoded=pcall(jsonDecode,values);values=ok and decoded or nil
 end
 local manual=tonumber(rawget(_G,'input_brake_angelo234'))
 -- Actual automatic brake request returned by ADAS+'s existing vehicle-data exchange.
 -- A forward vehicle must have been observed recently; no steering/pedal control changed.
 local automatic=type(values)=='table' and tonumber(values.brakeOverride) or nil
 if automatic and automatic>0.03 and manual and manual<=0.03 and now-frontSeen<0.5 then warningUntil=now+0.3 end
 local dir=0
 local ok,d=pcall(lane.getLaneData)
 if ok and type(d)=='table' and type(d.status)=='table' then
  local offset=d.lane and d.lane.offset
  if offset and (d.status.enabled or d.status.active) and ((d.assist and d.assist.warning) or math.abs(offset.normalized or 0)>=0.8) then
   local e=offset.error or offset.normalized or 0
   if e>0 then dir=2 elseif e<0 then dir=1 end
  end
 end
 if type(target)~='number' or target~=target or target<0 or target==math.huge then target=0;hardware=false end
 veh:queueLuaCommand(string.format('electrics.values.bmwBridgeWarning=%d;electrics.values.bmwBridgeLane=%d;electrics.values.bmwBridgeAccKnown=%d;electrics.values.bmwBridgeAcc=%d;electrics.values.bmwBridgeTarget=%.6f;electrics.values.bmwBridgeTTL=0.5',now<warningUntil and 1 or 0,dir,hardware and 1 or 0,accOn and 1 or 0,target))
end
local failed=false
local function onUpdate(dt)
 local ok,err=pcall(update,dt)
 if not ok and not failed and log then failed=true;log('E','bmwF10Bridge','Display observer disabled after error: '..tostring(err)) end
 if not ok then M.onUpdate=function()end end
end
local function onVehicleSwitched()active=false;accSeen=-100;frontSeen=-100;warningUntil=-100 end
local function onExtensionUnloaded()for i=#hooks,1,-1 do pcall(hooks[i])end;hooks={};hooked=false end
M.onUpdate=onUpdate;M.onVehicleSwitched=onVehicleSwitched;M.onExtensionUnloaded=onExtensionUnloaded
return M
