angular.module('beamng.apps').directive('autoHoldToggle', ['$injector', function ($injector) {
    return {
        templateUrl: '/ui/modules/apps/daSettings/app.html',
        replace: true,
        restrict: 'EA',
        link: function (scope, element, attrs) {
            scope.ssEnabled = true;
            scope.ahEnabled = true;
            scope.ssState = 'ssgrey';
            scope.ahState = 'ahgrey';
            scope.ssDelay = 2;
            scope.ssCountdown = -1;

            var hasStreams = $injector.has('StreamsManager');
            var streamsList = ['electrics'];

            if (hasStreams) {
                var StreamsManager = $injector.get('StreamsManager');
                StreamsManager.add(streamsList);
            }

            scope.$on('streamsUpdate', function (event, streams) {
                if (!streams || !streams.electrics) return;
                var e = streams.electrics;

                if (e.da_ssEnabled !== undefined)  scope.ssEnabled  = (e.da_ssEnabled === 1);
                if (e.da_ahEnabled !== undefined)  scope.ahEnabled  = (e.da_ahEnabled === 1);
                if (e.da_ssState   !== undefined)  scope.ssState    = e.da_ssState;
                if (e.da_ahState   !== undefined)  scope.ahState    = e.da_ahState;
                if (e.da_ssDelay   !== undefined)  scope.ssDelay    = e.da_ssDelay;
                if (e.da_ssCountdown !== undefined) scope.ssCountdown = e.da_ssCountdown;
            });

            scope.updateSS = function () {
                var val = scope.ssEnabled ? 1 : 0;
                bngApi.activeObjectLua('if drive_assist_core then drive_assist_core.setSsStatus(' + val + ') end');
            };

            scope.updateAH = function () {
                var val = scope.ahEnabled ? 1 : 0;
                bngApi.activeObjectLua('if drive_assist_core then drive_assist_core.setAhStatus(' + val + ') end');
            };

            scope.cycleDelay = function (event) {
                if (event) { event.stopPropagation(); }
                console.log('[DriveAssist] cycleDelay called');
                bngApi.activeObjectLua('if drive_assist_core then drive_assist_core.cycleSsDelay() end');
            };

            scope.$on('$destroy', function () {
                if (hasStreams) {
                    var StreamsManager = $injector.get('StreamsManager');
                    StreamsManager.remove(streamsList);
                }
            });
        }
    };
}]);
