local M = {}

local ssEnabled = true
local ahEnabled = true

local isEngineCut = false
local isIdling = false
local idleTimer = 0
local IDLE_WAIT_TIME = 2.0 -- 2.0 seconds delay for S&S alone
local SPEED_THRESHOLD = 0.3 -- speed limit to stop/hold

local ahBrakeHeld = false
local ahHoldingPressure = false
local AH_SPEED_LIMIT = 0.3

local MIN_OIL_TEMP = 45
local tempReached = false
local starterData = {}
local lastIgnitionLevel = 0
local maneuverActive = false
local maneuverStartTime = 0

local cutGearMode = ""
local cutGearIdx = 0

local function onExtensionLoaded()
    ssEnabled = true
    ahEnabled = true
    gui.message({txt = "Drive Assist Core: Active", context = {}}, 3, "vehicle.info")
end

local function reset()
    isEngineCut = false
    isIdling = false
    idleTimer = 0
    ahBrakeHeld = false
    ahHoldingPressure = false
    tempReached = false
    starterData = {}
    maneuverActive = false
    maneuverStartTime = 0
    cutGearMode = ""
    cutGearIdx = 0
end

local function cutPower(eng)
    starterData.tq = eng.starterTorque
    starterData.av = eng.starterMaxAV
    starterData.kt = eng.starterThrottleKillTime
    starterData.sc = eng.idleStartCoef

    eng.starterTorque = (starterData.tq * 3)
    eng.starterMaxAV = (eng.idleAV * 0.8)
    eng.starterThrottleKillTime = (starterData.kt / 3)
    eng.idleStartCoef = 1.5

    pcall(function() powertrain.getDevice("mainEngine").outputAV1 = 0 end)
    isEngineCut = true

    eng.starterTorque = starterData.tq
    eng.starterMaxAV = starterData.av
    eng.starterThrottleKillTime = starterData.kt
    eng.idleStartCoef = starterData.sc
end

local function revertStarterParams(eng)
    if starterData.tq then eng.starterTorque = starterData.tq end
    if starterData.av then eng.starterMaxAV = starterData.av end
    if starterData.kt then eng.starterThrottleKillTime = starterData.kt end
    if starterData.sc then eng.idleStartCoef = starterData.sc end
    starterData = {}
end

local function restorePower(eng)
    local tq = starterData.tq or eng.starterTorque
    local kt = starterData.kt or eng.starterThrottleKillTime

    eng.starterTorque = tq * 3
    eng.starterMaxAV = eng.idleAV * 0.8
    eng.starterThrottleKillTime = kt / 3
    eng.idleStartCoef = 1.5

    pcall(function() powertrain.getDevice("mainEngine"):activateStarter() end)
    isEngineCut = false

    revertStarterParams(eng)
end

local function setBrakeOverride(val)
    if electrics and electrics.values then
        electrics.values.brakeOverride = val and 1 or nil
    end
end

local function onUpdate(dt)
    local eng = powertrain.getDevice("mainEngine")
    local gb = powertrain.getDevice("gearbox")

    if not eng or eng.type ~= "combustionEngine" or not gb then
        if electrics and electrics.values then
            electrics.values.da_ssEnabled = ssEnabled and 1 or 0
            electrics.values.da_ahEnabled = ahEnabled and 1 or 0
            electrics.values.da_ssState = "ssgreyoff"
            electrics.values.da_ahState = "ahgreyoff"
            electrics.values.da_ssDelay = IDLE_WAIT_TIME
            electrics.values.da_ssCountdown = -1
        end
        return
    end

    local spd = (electrics.values.airspeed or 0) * 3.6
    local thr = electrics.values.throttle_input or 0
    local brk = electrics.values.brake_input or 0
    local clt = electrics.values.clutch_input or 0
    local pb = electrics.values.parkingbrake or 0
    local str = electrics.values.steering_input or 0
    local ign = electrics.values.ignitionLevel or 0

    -- Global Safety Logic
    -- 1. Auto-engage parking brake on manual engine cut (only under 0.5kph)
    if not isEngineCut and ign < 2 and lastIgnitionLevel >= 2 and spd <= 0.5 then
        if pb == 0 then
            input.event("parkingbrake", 1, 1)
            gui.message({txt = "Auto Safety: Parking Brake Engaged", context = {}}, 3, "vehicle.info")
        end
    end

    -- 2. Auto-release parking brake on gas
    if ign >= 2 and pb > 0 and thr > 0.05 then
        input.event("parkingbrake", 0, 1)
        gui.message({txt = "Auto Safety: Parking Brake Released", context = {}}, 2, "vehicle.info")
    end

    lastIgnitionLevel = ign

    -- Maneuvering Logic Check
    local gMode = gb.mode or ""
    local gIdx = gb.gearIndex or 0
    local isReverse = (gMode == "reverse" or gIdx == -1)
    
    if math.abs(str) > 0.5 then
        maneuverActive = true
        maneuverStartTime = os.time()
    end

    if maneuverActive then
        if spd > 6 or (os.time() - maneuverStartTime > 60) then
            maneuverActive = false
        end
    end

    local inhibit = (maneuverActive or isReverse)

    -- AutoHold Logic
    if ahEnabled then
        if ahBrakeHeld then
            if thr > 0.05 then
                ahBrakeHeld = false
                ahHoldingPressure = false
                setBrakeOverride(false)
                gui.message({txt = "AutoHold: Released", context = {}}, 2, "vehicle.info")
            end
        else
            if not inhibit and math.abs(str) <= 0.5 then
                if spd <= AH_SPEED_LIMIT and thr == 0 and brk > 0 then
                    ahBrakeHeld = true
                    ahHoldingPressure = true
                    setBrakeOverride(true)
                    gui.message({txt = "AutoHold: Active", context = {}}, 3, "vehicle.info")
                end
            end
        end

        if ahHoldingPressure then
            setBrakeOverride(true)
        end
    else
        if ahBrakeHeld then
            ahBrakeHeld = false
            ahHoldingPressure = false
            setBrakeOverride(false)
            gui.message({txt = "AutoHold: Released", context = {}}, 2, "vehicle.info")
        end
    end

    -- Start/Stop Logic
    local oilT = eng.thermals and eng.thermals.oilTemperature or 0
    if not tempReached and oilT >= MIN_OIL_TEMP then
        tempReached = true
        gui.message({txt = "Engine Temp Reached: S&S Ready", context = {}}, 4, "vehicle.info")
    end

    if isEngineCut then
        -- Manual ignition off override
        if ign < 2 then
            revertStarterParams(eng)
            isEngineCut = false
            isIdling = false
            idleTimer = 0
            gui.message({txt = "ISS: Reset due to manual ignition off", context = {}}, 3, "vehicle.info")
            return
        end

        -- Check conditions to start engine
        local shouldRestart = false

        if not ssEnabled then
            shouldRestart = true
        elseif thr > 0.05 or clt > 0.1 then
            shouldRestart = true
        elseif not ahEnabled then
            -- SS on alone restart conditions
            if brk < 0.15 then
                shouldRestart = true
            elseif gMode ~= cutGearMode or gIdx ~= cutGearIdx then
                shouldRestart = true
            end
        end

        if shouldRestart then
            restorePower(eng)
        end
    elseif ssEnabled and oilT >= MIN_OIL_TEMP then
        -- Conditions to cut engine
        local readyToStop = (spd <= SPEED_THRESHOLD) and (thr == 0) and (pb == 0) and (clt < 0.1) and not inhibit and (math.abs(str) <= 0.2)
        local isAuto = (gb.type ~= "manualGearbox" and gb.type ~= "sequentialGearbox")
        local inDrive = (isAuto and gMode == "drive") or (not isAuto and gIdx == 0)

        if readyToStop and inDrive then
            if ahEnabled then
                -- Both enabled: cut instantly when brake is pressed harder and AutoHold is holding
                if brk >= 0.5 and ahBrakeHeld then
                    cutPower(eng)
                    cutGearMode = gMode
                    cutGearIdx = gIdx
                    isIdling = false
                    idleTimer = 0
                end
            else
                -- SS alone: cut after delay of brake > 0.15
                if brk > 0.15 then
                    if not isIdling then
                        isIdling = true
                        idleTimer = 0
                    else
                        idleTimer = idleTimer + dt
                        if idleTimer >= IDLE_WAIT_TIME then
                            cutPower(eng)
                            cutGearMode = gMode
                            cutGearIdx = gIdx
                            isIdling = false
                            idleTimer = 0
                        end
                    end
                else
                    isIdling = false
                    idleTimer = 0
                end
            end
        else
            isIdling = false
            idleTimer = 0
        end
    else
        isIdling = false
        idleTimer = 0
    end

    -- Export variables to electrics stream for JS UI
    if electrics and electrics.values then
        electrics.values.da_ssEnabled = ssEnabled and 1 or 0
        electrics.values.da_ahEnabled = ahEnabled and 1 or 0

        -- S&S State
        local ssState = "ssgreyoff"
        if not ssEnabled then
            ssState = "ssgreyoff"
        elseif oilT < MIN_OIL_TEMP then
            ssState = "ssgrey"
        elseif isEngineCut then
            ssState = "ssactive"
        elseif isIdling then
            ssState = "ssyellow"
        else
            ssState = "ssgrey"
        end

        -- AutoHold State
        local ahState = "ahgreyoff"
        if not ahEnabled then
            ahState = "ahgreyoff"
        elseif ahBrakeHeld then
            ahState = "ahactive"
        else
            ahState = "ahgrey"
        end

        electrics.values.da_ssState = ssState
        electrics.values.da_ahState = ahState
        
        -- S&S Delay & Countdown values
        electrics.values.da_ssDelay = IDLE_WAIT_TIME
        electrics.values.da_ssCountdown = isIdling and math.max(0, IDLE_WAIT_TIME - idleTimer) or -1
    end
end

local function setSsStatus(val)
    local enabled = (val ~= 0)
    ssEnabled = enabled
    if not ssEnabled then
        local eng = powertrain.getDevice("mainEngine")
        if isEngineCut and eng then
            restorePower(eng)
        end
        isIdling = false
        idleTimer = 0
    end
end

local function setAhStatus(val)
    local enabled = (val ~= 0)
    ahEnabled = enabled
    if not ahEnabled then
        setBrakeOverride(false)
        ahBrakeHeld = false
        ahHoldingPressure = false
    end
end

local function cycleSsDelay()
    IDLE_WAIT_TIME = IDLE_WAIT_TIME + 1.0
    if IDLE_WAIT_TIME > 5.0 then
        IDLE_WAIT_TIME = 1.0
    end
    gui.message({txt = string.format("Start&Stop Delay set to %.0fs", IDLE_WAIT_TIME), context = {}}, 3, "vehicle.info")
end

-- Backward compatibility function
local function setSystemStatus(val)
    local enabled = (val ~= 0)
    setSsStatus(val)
    setAhStatus(val)
end

M.onExtensionLoaded = onExtensionLoaded
M.reset = reset
M.updateGFX = onUpdate
M.setSystemStatus = setSystemStatus
M.setSsStatus = setSsStatus
M.setAhStatus = setAhStatus
M.cycleSsDelay = cycleSsDelay

return M
