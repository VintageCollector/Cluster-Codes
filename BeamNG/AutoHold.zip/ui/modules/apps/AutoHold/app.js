angular.module('beamng.apps')
.directive('autohold', [function () {
  return {

    template:
      '<div class="bngApp" style="margin:0;padding:0;text-align:center;">' +
      '<p id="text" style="color:white">Auto Hold</p>' +
      '</div>',

    replace: true,

    controller: ['$scope', function ($scope) {
      $scope.autoHold = false
    }],

    link: function (scope, element, attrs) {
      scope.$on('streamsUpdate', function (event, streams) {
        var brakeVal = streams.electrics.brake
        var airspeed = streams.electrics.airspeed
        var throttle = streams.electrics.throttle

        // ACTIVATE
        if (airspeed <= 0.5 && brakeVal >= 0.20 && scope.autoHold == false) {

          document.getElementById("text").style.color = "#00FF00"

          bngApi.engineLua(
            'be:getPlayerVehicle(0):queueLuaCommand("electrics.values.brakeOverride = 1")'
          );

          scope.autoHold = true
        }
        
        // DEACTIVATE
        if (throttle > 0 && scope.autoHold == true) {
          document.getElementById("text").style.color = "white"

          bngApi.engineLua(
            'be:getPlayerVehicle(0):queueLuaCommand("electrics.values.brakeOverride = nil")'
          );

          scope.autoHold = false
       }

      });
      scope.$on('$destroy', function () {
        bngApi.engineLua(
            'be:getPlayerVehicle(0):queueLuaCommand("electrics.values.brakeOverride = nil")'
          );
      });
    }
  }
}]);
