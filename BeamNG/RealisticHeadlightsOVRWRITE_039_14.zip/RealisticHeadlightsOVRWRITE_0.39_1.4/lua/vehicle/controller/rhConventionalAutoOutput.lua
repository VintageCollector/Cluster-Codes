local M = {}

M.type = "auxiliary"

local lowElectricName = "rhConventionalAutoLow"
local highElectricName = "rhConventionalAutoHigh"

local function clearOutputs()
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  clearOutputs()
end

M.init = init
M.reset = clearOutputs
M.updateGFX = clearOutputs

return M
