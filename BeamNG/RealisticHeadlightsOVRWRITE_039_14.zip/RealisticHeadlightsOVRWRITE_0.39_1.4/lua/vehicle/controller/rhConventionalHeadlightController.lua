local M = {}

M.type = "auxiliary"

local max = math.max
local min = math.min

local lowElectricName = "rhConventionalLow"
local highElectricName = "rhConventionalHigh"
local autoLowElectricName = "rhConventionalAutoLow"
local autoHighElectricName = "rhConventionalAutoHigh"
local autoModeElectricName = "rhConventionalAutoMode"
local lowSourceName = "lowbeam"
local highSourceName = "highbeam"
local highSideSourceName = ""
local keepLowBeamWithHigh = false

local function clamp(value, minimum, maximum)
  return max(minimum, min(maximum, value))
end

local function signalValue(name)
  if not name or name == "" then
    return 0
  end
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return (tonumber(ignitionLevel) or 0) >= 1
  end
  return signalValue("engineRunning") > 0 or signalValue("ignition") > 0
end

local function clearOutputs()
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  autoLowElectricName = jbeamData.autoLowElectricName or autoLowElectricName
  autoHighElectricName = jbeamData.autoHighElectricName or autoHighElectricName
  autoModeElectricName = jbeamData.autoModeElectricName or autoModeElectricName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  highSideSourceName = jbeamData.highSideSourceName or highSideSourceName
  if jbeamData.keepLowBeamWithHigh ~= nil then
    keepLowBeamWithHigh = jbeamData.keepLowBeamWithHigh
  end
  clearOutputs()
end

local function updateGFX()
  if not isIgnitionPowered() then
    clearOutputs()
    return
  end

  local lowOutput = clamp(signalValue(lowSourceName), 0, 1)
  local highOutput = clamp(
    max(
      signalValue(highSourceName),
      signalValue(highSideSourceName),
      signalValue("highbeam")
    ),
    0,
    1
  )

  if signalValue(autoModeElectricName) > 0.5 then
    lowOutput = clamp(signalValue(autoLowElectricName), 0, 1)
    highOutput = clamp(signalValue(autoHighElectricName), 0, 1)
  end

  if highOutput > 0.01 then
    lowOutput = keepLowBeamWithHigh and max(lowOutput, highOutput) or 0
  end

  electrics.values[lowElectricName] = lowOutput
  electrics.values[highElectricName] = highOutput
end

M.init = init
M.reset = clearOutputs
M.updateGFX = updateGFX

return M
