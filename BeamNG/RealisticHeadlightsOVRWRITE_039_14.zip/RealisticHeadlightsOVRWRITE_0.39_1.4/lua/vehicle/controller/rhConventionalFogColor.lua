local M = {}

M.type = "auxiliary"

local max = math.max
local min = math.min

local colorR = 255
local colorG = 255
local colorB = 255
local materialName = "vehicle_lights"
local targetMeshes = {}
local intensitySignals = {"fog"}
local materialSwitches = {}
local elapsedTime = 0
local nextMaterialSearch = 0

local function clamp(value, minimum, maximum)
  return max(minimum, min(maximum, value))
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return (tonumber(ignitionLevel) or 0) >= 2
  end
  return signalValue("engineRunning") > 0 or signalValue("ignition") > 0
end

local function findMaterialSwitches()
  materialSwitches = {}
  local allowedMeshes = {}
  for _, meshName in ipairs(targetMeshes) do
    allowedMeshes[meshName] = true
  end
  local materialData = v.data._materials
  local triggers = materialData and materialData.triggers or {}
  for _, trigger in pairs(triggers) do
    local materialSwitch = tonumber(trigger.msc)
    if trigger.orgMat == materialName
      and allowedMeshes[trigger.mesh]
      and materialSwitch
      and materialSwitch >= 0 then
      materialSwitches[#materialSwitches + 1] = materialSwitch
    end
  end
end

local function currentIntensity()
  if not isIgnitionPowered() then
    return 0
  end
  local intensity = 0
  for _, signalName in ipairs(intensitySignals) do
    intensity = max(intensity, signalValue(signalName))
  end
  return clamp(intensity, 0, 1)
end

local function applyColor()
  if #materialSwitches == 0 and elapsedTime >= nextMaterialSearch then
    findMaterialSwitches()
    nextMaterialSearch = elapsedTime + 0.5
  end
  local intensity = currentIntensity()
  for _, materialSwitch in ipairs(materialSwitches) do
    obj:setMaterialEmissiveFactor(
      materialSwitch,
      color(colorR * intensity, colorG * intensity, colorB * intensity)
    )
  end
end

local function reset()
  elapsedTime = 0
  nextMaterialSearch = 0
  findMaterialSwitches()
  applyColor()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  local fixedColor = type(jbeamData.color) == "table" and jbeamData.color or {}
  colorR = clamp(tonumber(fixedColor.r) or colorR, 0, 255)
  colorG = clamp(tonumber(fixedColor.g) or colorG, 0, 255)
  colorB = clamp(tonumber(fixedColor.b) or colorB, 0, 255)
  materialName = tostring(jbeamData.materialName or materialName)
  targetMeshes = type(jbeamData.targetMeshes) == "table" and jbeamData.targetMeshes or {}
  intensitySignals = type(jbeamData.intensitySignals) == "table" and jbeamData.intensitySignals or {"fog"}
  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + max(dt or 0, 0)
  applyColor()
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
