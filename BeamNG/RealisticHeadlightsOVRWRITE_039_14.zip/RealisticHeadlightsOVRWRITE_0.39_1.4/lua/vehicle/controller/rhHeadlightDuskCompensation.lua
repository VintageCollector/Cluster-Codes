local M = {}

M.type = "auxiliary"

local max = math.max
local min = math.min
local stringFormat = string.format

local channels = {}
local environmentElectricName = "rhHeadlightDuskEnvironment"
local boostElectricName = "rhHeadlightDuskBoost"
local environmentPollInterval = 1
local twilightFullWindow = 0.055
local twilightFadeWindow = 0.14
local boostResponse = 3
local boostMultiplier = 6

local environmentLightLevel = 0
local environmentPollTimer = 0
local currentBoost = 0

local function clamp(value, minimum, maximum)
  return min(max(value, minimum), maximum)
end

local function signalValue(name)
  if not name or name == "" then
    return 0
  end
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return (tonumber(ignitionLevel) or 0) >= 1
  end
  return signalValue("engineRunning") > 0
    or signalValue("ignition") > 0
end

local function clearOutputs()
  electrics.values[boostElectricName] = 0
  for _, channel in ipairs(channels) do
    electrics.values[channel.output] = 0
  end
end

local function requestEnvironmentLight(dt)
  local sharedLevel = electrics.values[environmentElectricName]
  if sharedLevel ~= nil then
    environmentLightLevel = clamp(
      tonumber(sharedLevel) or environmentLightLevel,
      0,
      1.5
    )
  end

  environmentPollTimer = environmentPollTimer + max(dt or 0, 0)
  if environmentPollTimer < environmentPollInterval then
    return
  end
  environmentPollTimer = 0

  if obj and obj.queueGameEngineLua then
    local vehicleId = obj:getID()
    obj:queueGameEngineLua(
      stringFormat(
        "local veh=getObjectByID(%d); if veh then local state=core_environment and core_environment.getLightState and core_environment.getLightState(); if state and state.time~=nil and state.nightStart~=nil and state.nightEnd~=nil then local level=0; local t=(tonumber(state.time) or 0)%%1; local function circularDistance(a,b) local d=math.abs(a-b)%%1; return math.min(d,1-d) end; local distance=math.min(circularDistance(t,(tonumber(state.nightStart) or 0)%%1),circularDistance(t,(tonumber(state.nightEnd) or 0)%%1)); local full=%0.4f; local fade=math.max(full+0.001,%0.4f); if distance<=full then level=1 elseif distance<fade then local blend=(fade-distance)/(fade-full); level=blend*blend*(3-2*blend) end; veh:queueLuaCommand('electrics.values[%q]='..tostring(level)) end end",
        vehicleId,
        twilightFullWindow,
        twilightFadeWindow,
        environmentElectricName
      )
    )
  end
end

local function targetBoost()
  return clamp(environmentLightLevel or 0, 0, 1)
end

local function updateGFX(dt)
  if not isIgnitionPowered() then
    currentBoost = 0
    clearOutputs()
    return
  end

  requestEnvironmentLight(dt)
  local response = min(max(dt or 0, 0) * boostResponse, 1)
  currentBoost = currentBoost
    + (targetBoost() - currentBoost) * response
  electrics.values[boostElectricName] = currentBoost

  for _, channel in ipairs(channels) do
    local source = signalValue(channel.source)
    for _, sourceName in ipairs(channel.alternateSources or {}) do
      source = max(source, signalValue(sourceName))
    end
    source = clamp(source, 0, 1)
    -- One emitter carries both its normal output and the dusk boost. Keeping
    -- the value above 1 avoids a second overlapping projected spotlight.
    electrics.values[channel.output] = source
      * (1 + currentBoost * boostMultiplier)
  end
end

local function reset()
  environmentLightLevel = 0
  environmentPollTimer = environmentPollInterval
  currentBoost = 0
  clearOutputs()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  channels = jbeamData.channels or {}
  environmentElectricName = jbeamData.environmentElectricName
    or environmentElectricName
  boostElectricName = jbeamData.boostElectricName
    or boostElectricName
  environmentPollInterval = tonumber(jbeamData.environmentPollInterval)
    or environmentPollInterval
  twilightFullWindow = tonumber(jbeamData.twilightFullWindow)
    or twilightFullWindow
  twilightFadeWindow = tonumber(jbeamData.twilightFadeWindow)
    or twilightFadeWindow
  twilightFadeWindow = max(
    twilightFadeWindow,
    twilightFullWindow + 0.001
  )
  boostResponse = tonumber(jbeamData.boostResponse) or boostResponse
  boostMultiplier = max(
    tonumber(jbeamData.boostMultiplier) or boostMultiplier,
    0
  )
  reset()
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
