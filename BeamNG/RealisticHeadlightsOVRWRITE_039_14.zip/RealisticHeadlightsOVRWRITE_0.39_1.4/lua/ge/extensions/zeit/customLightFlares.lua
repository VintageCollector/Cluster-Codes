-- written by DaddelZeit
-- DO NOT USE WITHOUT PERMISSION

local M = {}

local function loadFile()
    loadJsonMaterialsFile("lua/ge/extensions/zeit/customLightFlares.json")
end

local function onFileChanged(file)
    -- check if we're actually in a mission before loading again
    if not TorqueScriptLua.getVar("$missionRunning") == "1" then return end
    if file:match("lua/ge/extensions/zeit/customLightFlares.json") then
        loadFile()
    end
end

-- hotloading support
M.onFileChanged = onFileChanged -- hotloading support
M.onClientPreStartMission = loadFile

return M