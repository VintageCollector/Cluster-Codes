local M = {}
M.type = "auxiliary"

local side = "R"
local mode = "factory"
local brightness = 0.5
local whiteElectricName = "scintillaDRLWhiteR"
local yellowElectricName = "scintillaDRLYellowR"
local extraWhiteElectricName = "scintillaDRLExtraWhiteR"
local extraYellowElectricName = "scintillaDRLExtraYellowR"
local fixedElectricName = "scintillaDRLFixedR"
local flashSourceName = "highbeam"
local flashRequired = 5
local flashWindow = 3
local maxFlashGap = 0.8
local fadeDuration = 1.25

local targetMesh = "scintilla_headlight_R"
local materialSwitches = {}
local elapsedTime = 0
local nextMaterialSearch = 0
local flashCount = 0
local sequenceStart = 0
local lastFlashTime = -1
local lastHigh = false
local colorMix = 0
local targetColorMix = 0

local whiteR = 255
local whiteG = 255
local whiteB = 255
local yellowR = 255
local yellowG = 255
local yellowB = 0
local fixedR = 255
local fixedG = 255
local fixedB = 255
local hasBaseDRLEmitters = false
local hasFixedDRLEmitters = false

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function calibratedBrightness(value)
  if value <= 0.5 then
    return value * 2
  end
  return 1 + (value - 0.5)
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function clearFlashSequence()
  flashCount = 0
  sequenceStart = 0
  lastFlashTime = -1
end

local function findMaterialSwitches()
  materialSwitches = {}
  local materialData = v.data._materials
  local triggers = materialData and materialData.triggers or {}

  for _, trigger in pairs(triggers) do
    local materialSwitch = tonumber(trigger.msc)
    if trigger.orgMat == "scintilla_runninglight" and trigger.mesh == targetMesh and materialSwitch and materialSwitch >= 0 then
      materialSwitches[#materialSwitches + 1] = materialSwitch
    end
  end
end

local function findBaseDRLEmitters()
  hasBaseDRLEmitters = false
  hasFixedDRLEmitters = false
  for _, prop in pairs(v.data.props or {}) do
    if prop.func == whiteElectricName then
      hasBaseDRLEmitters = true
    elseif prop.func == fixedElectricName then
      hasFixedDRLEmitters = true
    end
  end
end

local function updateFlashToggle()
  local highNow = signalValue(flashSourceName) > 0.5

  if flashCount > 0 and (elapsedTime - sequenceStart > flashWindow or elapsedTime - lastFlashTime > maxFlashGap) then
    clearFlashSequence()
  end

  if highNow and not lastHigh then
    local sequenceExpired = flashCount == 0
      or elapsedTime - sequenceStart > flashWindow
      or elapsedTime - lastFlashTime > maxFlashGap

    if sequenceExpired then
      flashCount = 1
      sequenceStart = elapsedTime
    else
      flashCount = flashCount + 1
    end
    lastFlashTime = elapsedTime

    if flashCount >= flashRequired then
      targetColorMix = targetColorMix < 0.5 and 1 or 0
      clearFlashSequence()
    end
  end

  lastHigh = highNow
end

local function updateColorFade(dt)
  if fadeDuration <= 0 then
    colorMix = targetColorMix
    return
  end

  local step = math.max(dt or 0, 0) / fadeDuration
  if colorMix < targetColorMix then
    colorMix = math.min(colorMix + step, targetColorMix)
  elseif colorMix > targetColorMix then
    colorMix = math.max(colorMix - step, targetColorMix)
  end
end

local function applyDRLMaterial(running, outputScale, colorR, colorG, colorB)
  if #materialSwitches == 0 and elapsedTime >= nextMaterialSearch then
    findMaterialSwitches()
    nextMaterialSearch = elapsedTime + 0.5
  end

  local intensity = math.min(outputScale, 1) * running
  local red = colorR * intensity
  local green = colorG * intensity
  local blue = colorB * intensity

  for _, materialSwitch in ipairs(materialSwitches) do
    obj:setMaterialEmissiveFactor(materialSwitch, color(red, green, blue))
  end
end

local function reset()
  elapsedTime = 0
  nextMaterialSearch = 0
  clearFlashSequence()
  colorMix = 0
  targetColorMix = 0
  lastHigh = signalValue(flashSourceName) > 0.5
  local running = clamp(signalValue("running"), 0, 1)
  local outputScale = calibratedBrightness(brightness)
  local extraOutput = running * math.max(outputScale - 1, 0)

  electrics.values[whiteElectricName] = mode == "factory" and running
    or mode == "beamababa" and running * outputScale
    or 0
  electrics.values[yellowElectricName] = 0
  electrics.values[extraWhiteElectricName] = mode == "beamababa" and extraOutput or 0
  electrics.values[extraYellowElectricName] = 0
  electrics.values[fixedElectricName] = mode == "fixed"
    and (hasFixedDRLEmitters and running * outputScale or extraOutput)
    or 0
  electrics.values["scintillaDRLBeamABabaMix" .. side] = 0
  electrics.values["scintillaDRLBeamABabaFlashCount" .. side] = 0
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  side = string.upper(tostring(jbeamData.side or side))
  mode = string.lower(tostring(jbeamData.mode or mode))
  brightness = clamp(tonumber(jbeamData.brightness) or brightness, 0, 1)
  whiteElectricName = jbeamData.whiteElectricName or ("scintillaDRLWhite" .. side)
  yellowElectricName = jbeamData.yellowElectricName or ("scintillaDRLYellow" .. side)
  extraWhiteElectricName = "scintillaDRLExtraWhite" .. side
  extraYellowElectricName = "scintillaDRLExtraYellow" .. side
  fixedElectricName = jbeamData.fixedElectricName or ("scintillaDRLFixed" .. side)
  local fixedColor = type(jbeamData.fixedColor) == "table" and jbeamData.fixedColor or {}
  fixedR = clamp(tonumber(fixedColor.r) or fixedR, 0, 255)
  fixedG = clamp(tonumber(fixedColor.g) or fixedG, 0, 255)
  fixedB = clamp(tonumber(fixedColor.b) or fixedB, 0, 255)
  flashSourceName = jbeamData.flashSourceName or flashSourceName
  flashRequired = math.max(1, math.floor(tonumber(jbeamData.flashRequired) or flashRequired))
  flashWindow = math.max(0.1, tonumber(jbeamData.flashWindow) or flashWindow)
  maxFlashGap = math.max(0.1, tonumber(jbeamData.maxFlashGap) or maxFlashGap)
  fadeDuration = math.max(0, tonumber(jbeamData.fadeDuration) or fadeDuration)
  targetMesh = "scintilla_headlight_" .. side
  findMaterialSwitches()
  findBaseDRLEmitters()
  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + math.max(dt or 0, 0)
  local running = clamp(signalValue("running"), 0, 1)
  local outputScale = calibratedBrightness(brightness)
  local extraOutput = running * math.max(outputScale - 1, 0)

  if mode == "beamababa" then
    updateFlashToggle()
    updateColorFade(dt)
    local red = whiteR + (yellowR - whiteR) * colorMix
    local green = whiteG + (yellowG - whiteG) * colorMix
    local blue = whiteB + (yellowB - whiteB) * colorMix
    applyDRLMaterial(running, outputScale, red, green, blue)
    electrics.values[whiteElectricName] = running * outputScale * (1 - colorMix)
    electrics.values[yellowElectricName] = running * outputScale * colorMix
    electrics.values[extraWhiteElectricName] = extraOutput * (1 - colorMix)
    electrics.values[extraYellowElectricName] = extraOutput * colorMix
    electrics.values[fixedElectricName] = 0
  elseif mode == "fixed" then
    applyDRLMaterial(running, outputScale, fixedR, fixedG, fixedB)
    electrics.values[whiteElectricName] = 0
    electrics.values[yellowElectricName] = 0
    electrics.values[extraWhiteElectricName] = 0
    electrics.values[extraYellowElectricName] = 0
    electrics.values[fixedElectricName] = hasFixedDRLEmitters and running * outputScale or extraOutput
  else
    applyDRLMaterial(running, 1, whiteR, whiteG, whiteB)
    electrics.values[whiteElectricName] = running
    electrics.values[yellowElectricName] = 0
    electrics.values[extraWhiteElectricName] = 0
    electrics.values[extraYellowElectricName] = 0
    electrics.values[fixedElectricName] = 0
  end

  electrics.values["scintillaDRLBeamABabaMix" .. side] = colorMix
  electrics.values["scintillaDRLBeamABabaFlashCount" .. side] = flashCount
  electrics.values["scintillaDRLBeamABabaOutput" .. side] = outputScale
  electrics.values["scintillaDRLFixedHasBaseEmitters" .. side] = hasBaseDRLEmitters and 1 or 0
  electrics.values["scintillaDRLFixedHasColorEmitters" .. side] = hasFixedDRLEmitters and 1 or 0
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
