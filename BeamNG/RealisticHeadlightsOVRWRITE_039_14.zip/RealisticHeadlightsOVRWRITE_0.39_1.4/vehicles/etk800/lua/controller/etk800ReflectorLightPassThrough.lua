local M = {}

M.type = "auxiliary"

local max = math.max

local lowElectricName = "etk800ReflectorLowR"
local highElectricName = "etk800ReflectorHighR"
local lowSourceName = "lowhighbeam"
local highSourceName = "highbeam"

local function reset()
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
end

local function init(jbeamData)
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  reset()
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return ignitionLevel >= 1
  end

  return (electrics.values.engineRunning or 0) > 0
    or (electrics.values.running or 0) > 0
    or (electrics.values.ignition or 0) > 0
end

local function updateGFX()
  if not isIgnitionPowered() then
    reset()
    return
  end

  local highOutput = max(electrics.values[highSourceName] or 0, electrics.values.highbeam or 0)
  local lowOutput = max(electrics.values[lowSourceName] or 0, electrics.values.lowbeam or 0, highOutput)

  electrics.values[lowElectricName] = lowOutput
  electrics.values[highElectricName] = highOutput
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
