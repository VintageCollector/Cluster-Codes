local M = {}
M.type = "auxiliary"

local colorR = 255
local colorG = 255
local colorB = 255
local targetMeshes = {}
local materialSwitches = {}
local elapsedTime = 0
local nextMaterialSearch = 0

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function findMaterialSwitches()
  materialSwitches = {}
  local allowedMeshes = {}
  for _, meshName in ipairs(targetMeshes) do
    allowedMeshes[meshName] = true
  end

  local materialData = v.data._materials
  local triggers = materialData and materialData.triggers or {}
  for _, trigger in pairs(triggers) do
    local materialSwitch = tonumber(trigger.msc)
    if trigger.orgMat == "etk800_foglight"
      and allowedMeshes[trigger.mesh]
      and materialSwitch
      and materialSwitch >= 0 then
      materialSwitches[#materialSwitches + 1] = materialSwitch
    end
  end
end

local function applyColor()
  if #materialSwitches == 0 and elapsedTime >= nextMaterialSearch then
    findMaterialSwitches()
    nextMaterialSearch = elapsedTime + 0.5
  end

  local intensity = clamp(signalValue("fog"), 0, 1)
  local red = colorR * intensity
  local green = colorG * intensity
  local blue = colorB * intensity
  for _, materialSwitch in ipairs(materialSwitches) do
    obj:setMaterialEmissiveFactor(materialSwitch, color(red, green, blue))
  end
end

local function reset()
  elapsedTime = 0
  nextMaterialSearch = 0
  findMaterialSwitches()
  applyColor()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  local fixedColor = type(jbeamData.color) == "table" and jbeamData.color or {}
  colorR = clamp(tonumber(fixedColor.r) or colorR, 0, 255)
  colorG = clamp(tonumber(fixedColor.g) or colorG, 0, 255)
  colorB = clamp(tonumber(fixedColor.b) or colorB, 0, 255)

  targetMeshes = {}
  if type(jbeamData.targetMeshes) == "table" then
    for _, meshName in ipairs(jbeamData.targetMeshes) do
      if type(meshName) == "string" and meshName ~= "" then
        targetMeshes[#targetMeshes + 1] = meshName
      end
    end
  elseif type(jbeamData.targetMeshes) == "string" and jbeamData.targetMeshes ~= "" then
    targetMeshes[1] = jbeamData.targetMeshes
  end

  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + math.max(dt or 0, 0)
  applyColor()
  electrics.values.etk800FogColorMaterialCount = #materialSwitches
  electrics.values.etk800FogColorR = colorR
  electrics.values.etk800FogColorG = colorG
  electrics.values.etk800FogColorB = colorB
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
