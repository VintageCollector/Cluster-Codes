local M = {}

M.type = "auxiliary"

local lowHighElectricName = "rhBxIgnitionLowHighR"
local lowElectricName = "rhBxIgnitionLowR"
local highElectricName = "rhBxIgnitionHighR"
local powerElectricName = "rhBxIgnitionPowerR"
local lowHighSourceName = "lowhighbeam"
local lowSourceName = "lowbeam"
local highSourceName = "highbeam"

local function reset()
  electrics.values[lowHighElectricName] = 0
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
  electrics.values[powerElectricName] = 0
end

local function init(jbeamData)
  lowHighElectricName = jbeamData.lowHighElectricName or lowHighElectricName
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  powerElectricName = jbeamData.powerElectricName or powerElectricName
  lowHighSourceName = jbeamData.lowHighSourceName or lowHighSourceName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  reset()
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return ignitionLevel >= 1
  end

  return (electrics.values.engineRunning or 0) > 0
    or (electrics.values.running or 0) > 0
    or (electrics.values.ignition or 0) > 0
end

local function updateGFX()
  if not isIgnitionPowered() then
    reset()
    return
  end

  electrics.values[lowHighElectricName] = electrics.values[lowHighSourceName] or 0
  electrics.values[lowElectricName] = electrics.values[lowSourceName] or 0
  electrics.values[highElectricName] = electrics.values[highSourceName] or 0
  electrics.values[powerElectricName] = 1
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
