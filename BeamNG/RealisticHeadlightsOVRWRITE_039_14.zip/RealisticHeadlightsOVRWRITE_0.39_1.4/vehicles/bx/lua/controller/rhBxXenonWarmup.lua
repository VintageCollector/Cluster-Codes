local M = {}

M.type = "auxiliary"

local exp = math.exp
local max = math.max

local lowHighElectricName = "rhBxXenonLowHighR"
local lowElectricName = "rhBxXenonLowR"
local lowHighSourceName = "lowhighbeam"
local lowSourceName = "lowbeam"
local hidWarmupResponse = 0.75
local hidFadeOutResponse = 9
local hidWarmupFloor = 0.01
local hidWarmup = 0

local function smoothTowards(current, target, response, dt)
  return current + (target - current) * (1 - exp(-response * dt))
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return ignitionLevel >= 1
  end

  return (electrics.values.engineRunning or 0) > 0
    or (electrics.values.running or 0) > 0
    or (electrics.values.ignition or 0) > 0
end

local function reset()
  hidWarmup = 0
  electrics.values[lowHighElectricName] = 0
  electrics.values[lowElectricName] = 0
end

local function init(jbeamData)
  lowHighElectricName = jbeamData.lowHighElectricName or lowHighElectricName
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  lowHighSourceName = jbeamData.lowHighSourceName or lowHighSourceName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  if jbeamData.hidWarmupResponse ~= nil then hidWarmupResponse = jbeamData.hidWarmupResponse end
  if jbeamData.hidFadeOutResponse ~= nil then hidFadeOutResponse = jbeamData.hidFadeOutResponse end
  if jbeamData.hidWarmupFloor ~= nil then hidWarmupFloor = jbeamData.hidWarmupFloor end
  reset()
end

local function updateGFX(dt)
  local lowHighInput = electrics.values[lowHighSourceName] or 0
  local lowInput = electrics.values[lowSourceName] or 0
  local lightsOn = isIgnitionPowered() and max(lowHighInput, lowInput) > 0.01

  if lightsOn then
    hidWarmup = smoothTowards(hidWarmup, 1, hidWarmupResponse, dt or 0)
    local warmupOutput = hidWarmupFloor + (1 - hidWarmupFloor) * hidWarmup
    electrics.values[lowHighElectricName] = lowHighInput * warmupOutput
    electrics.values[lowElectricName] = lowInput * warmupOutput
  else
    hidWarmup = 0
    electrics.values[lowHighElectricName] = 0
    electrics.values[lowElectricName] = 0
  end
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
