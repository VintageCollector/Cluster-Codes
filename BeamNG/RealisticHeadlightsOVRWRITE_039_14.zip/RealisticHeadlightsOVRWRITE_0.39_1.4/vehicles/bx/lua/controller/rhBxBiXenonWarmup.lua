local M = {}

M.type = "auxiliary"

local exp = math.exp
local max = math.max

local lowHighElectricName = "rhBxPopupXenonLowHighR"
local lowElectricName = "rhBxPopupXenonLowR"
local highElectricName = "rhBxPopupXenonHighR"
local lowHighSourceName = "lowhighbeam"
local lowSourceName = "lowbeam"
local highSourceName = "highbeam"
local highSwitchThreshold = 0.5
local hidWarmupResponse = 0.75
local hidFadeOutResponse = 9
local hidWarmupFloor = 0.01
local hidWarmup = 0

local function smoothTowards(current, target, response, dt)
  return current + (target - current) * (1 - exp(-response * dt))
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return ignitionLevel >= 1
  end

  return (electrics.values.engineRunning or 0) > 0
    or (electrics.values.running or 0) > 0
    or (electrics.values.ignition or 0) > 0
end

local function reset()
  hidWarmup = 0
  electrics.values[lowHighElectricName] = 0
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
end

local function init(jbeamData)
  lowHighElectricName = jbeamData.lowHighElectricName or lowHighElectricName
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  lowHighSourceName = jbeamData.lowHighSourceName or lowHighSourceName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  if jbeamData.highSwitchThreshold ~= nil then highSwitchThreshold = jbeamData.highSwitchThreshold end
  if jbeamData.hidWarmupResponse ~= nil then hidWarmupResponse = jbeamData.hidWarmupResponse end
  if jbeamData.hidFadeOutResponse ~= nil then hidFadeOutResponse = jbeamData.hidFadeOutResponse end
  if jbeamData.hidWarmupFloor ~= nil then hidWarmupFloor = jbeamData.hidWarmupFloor end
  reset()
end

local function updateGFX(dt)
  local lowHighInput = electrics.values[lowHighSourceName] or 0
  local lowInput = electrics.values[lowSourceName] or 0
  local highInput = electrics.values[highSourceName] or 0
  local lightsOn = isIgnitionPowered() and max(lowHighInput, lowInput, highInput) > 0.01

  if lightsOn then
    hidWarmup = smoothTowards(hidWarmup, 1, hidWarmupResponse, dt or 0)
    local warmupOutput = hidWarmupFloor + (1 - hidWarmupFloor) * hidWarmup
    local highMode = highInput > highSwitchThreshold
    electrics.values[lowHighElectricName] = highMode and 0 or lowHighInput * warmupOutput
    electrics.values[lowElectricName] = highMode and 0 or lowInput * warmupOutput
    electrics.values[highElectricName] = highMode and warmupOutput or 0
  else
    hidWarmup = 0
    electrics.values[lowHighElectricName] = 0
    electrics.values[lowElectricName] = 0
    electrics.values[highElectricName] = 0
  end
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
