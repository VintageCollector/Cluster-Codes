-- written by DaddelZeit
-- DO NOT USE WITHOUT PERMISSION

local M = {}

local maxEmissionL = 0
local maxEmissionR = 0

local matL
local matR

-- fade
local corneringSmootherL = newExponentialSmoothingT(30)
local corneringSmootherR = newExponentialSmoothingT(30)
corneringSmootherL:set(0)
corneringSmootherR:set(0)

local corneringDataL = {}
local corneringDataR = {}

local fadeMaterial = false
local fadeSpotlight = false
local fadeActive = false
local targetSmoothLeft = 0
local targetSmoothRight = 0
local targetObjectId = 0

local leftIsOn = false
local rightIsOn = false

local function setCorneringElectrics(leftValue, rightValue)
    electrics.values.cornering_L = leftValue
    electrics.values.cornering_R = rightValue
end

local function updateGFX(dt)
    local fog = electrics.values.fog or 0
    local wheelSpeed = electrics.values.wheelspeed or 0
    local lowHighBeam = math.max(electrics.values.lowhighbeam or 0, electrics.values.lowbeam or 0)
    local steering = electrics.values.steering or 0

    if fog == 0 and lowHighBeam ~= 0 and wheelSpeed >= 0.0 and wheelSpeed <= 13.4 then
        leftIsOn = steering > 70
        rightIsOn = steering < -70
    else
        leftIsOn = false
        rightIsOn = false
    end

    if leftIsOn then
        setCorneringElectrics(1, 0)
    elseif rightIsOn then
        setCorneringElectrics(0, 1)
    else
        setCorneringElectrics(0, 0)
    end
end
local function updateSpotLights(fadeValL, fadeValR)
    scenetree.findObject(targetObjectId):getProp(corneringDataL.propIndex):getLight():setLightArgs(
    corneringDataL.innerAngle,
    corneringDataL.outerAngle,
    ((fadeValL*corneringDataL.maxBrightness)/100),
    corneringDataL.range,
    ColorF(corneringDataL.color.r,corneringDataL.color.g,corneringDataL.color.b,corneringDataL.color.a),
    vec3(corneringDataL.attenuation.x,corneringDataL.attenuation.y,corneringDataL.attenuation.y),
    corneringDataL.castShadows)

    scenetree.findObject(targetObjectId):getProp(corneringDataR.propIndex):getLight():setLightArgs(
    corneringDataR.innerAngle,
    corneringDataR.outerAngle,
    ((fadeValR*corneringDataR.maxBrightness)/100),
    corneringDataR.range,
    ColorF(corneringDataR.color.r,corneringDataR.color.g,corneringDataR.color.b,corneringDataR.color.a),
    vec3(corneringDataR.attenuation.x,corneringDataR.attenuation.y,corneringDataR.attenuation.y),
    corneringDataR.castShadows)
end

local function updateEmission(emissionScaleL, emissionScaleR)
    local newEmissionL = maxEmissionL * emissionScaleL
    local newEmissionR = maxEmissionR * emissionScaleR

    matL:setField("emissiveFactor", 0, newEmissionL.." "..newEmissionL.." "..newEmissionL)
    matL:flush()
    matL:reload()
    matR:setField("emissiveFactor", 0, newEmissionR.." "..newEmissionR.." "..newEmissionR)
    matR:flush()
    matR:reload()
end

local function onUpdate(dt)
    updateGFX(dt)
    if not fadeActive then return end

    local fadeValL = corneringSmootherL:get(targetSmoothLeft)
    local fadeValR = corneringSmootherR:get(targetSmoothRight)

    if fadeValL > 0.995 then fadeValL = 1 elseif fadeValL < 0.005 then fadeValL = 0 end
    if fadeValR > 0.995 then fadeValR = 1 elseif fadeValR < 0.005 then fadeValR = 0 end

    if fadeMaterial then
        updateEmission(fadeValL, fadeValR)
    end
    if fadeSpotlight then
        updateSpotLights(fadeValL, fadeValR)
    end

    if fadeValL == targetSmoothLeft and fadeValR == targetSmoothRight then
        fadeActive = false
    end
end

local function callSmoothStart(targetL, targetR, id)
    fadeActive = true
    targetSmoothLeft = targetL or 0
    targetSmoothRight = targetR or 0
    targetObjectId = id
end

local function initEmissionEdit(newMatNameL, newMatNameR)
    if not matL and not matR then
        if newMatNameL then matL = scenetree.findObject(newMatNameL) else M.updateEmission = nop return end
        if newMatNameR then matR = scenetree.findObject(newMatNameR) else M.updateEmission = nop return end

        maxEmissionL = matL.emissiveFactor.x
        maxEmissionR = matR.emissiveFactor.x

        updateEmission(0,0)

        fadeMaterial = true
    end
end

local function initSpotLightEdit(corneringData)
    corneringDataL = corneringData.left
    corneringDataR = corneringData.right

    fadeSpotlight = true
end

local function reset()
    matL = nil
    matR = nil
    leftIsOn = false
    rightIsOn = false
    if electrics and electrics.values then
        setCorneringElectrics(0, 0)
    end
end

local function onExtensionLoaded()
end

M.callSmoothStart = callSmoothStart
M.onUpdate = onUpdate
M.updateGFX = updateGFX
M.updateSpotLights = updateSpotLights
M.updateEmission = updateEmission
M.initEmissionEdit = initEmissionEdit
M.initSpotLightEdit = initSpotLightEdit
M.onExtensionLoaded = onExtensionLoaded
M.init = reset
M.reset = reset

return M