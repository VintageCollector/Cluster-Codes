local M = {}
M.type = "auxiliary"

local side = "R"
local mode = "fixed"
local brightness = 0.5
local whiteElectricName = "sbrDRLWhiteR"
local yellowElectricName = "sbrDRLYellowR"
local fixedElectricName = "sbrDRLFixedR"
local amberElectricName = "sbrDRLAmberR"
local flashSourceName = "highbeam"
local flashRequired = 5
local flashWindow = 3
local maxFlashGap = 0.8
local fadeDuration = 1.25

local elapsedTime = 0
local flashCount = 0
local sequenceStart = 0
local lastFlashTime = -1
local lastHigh = false
local colorMix = 0
local targetColorMix = 0

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function calibratedBrightness(value)
  if value <= 0.5 then
    return value * 2
  end
  return 1 + (value - 0.5)
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function clearFlashSequence()
  flashCount = 0
  sequenceStart = 0
  lastFlashTime = -1
end

local function updateFlashToggle()
  local highNow = signalValue(flashSourceName) > 0.5

  if flashCount > 0 and (elapsedTime - sequenceStart > flashWindow or elapsedTime - lastFlashTime > maxFlashGap) then
    clearFlashSequence()
  end

  if highNow and not lastHigh then
    local sequenceExpired = flashCount == 0
      or elapsedTime - sequenceStart > flashWindow
      or elapsedTime - lastFlashTime > maxFlashGap

    if sequenceExpired then
      flashCount = 1
      sequenceStart = elapsedTime
    else
      flashCount = flashCount + 1
    end
    lastFlashTime = elapsedTime

    if flashCount >= flashRequired then
      targetColorMix = targetColorMix < 0.5 and 1 or 0
      clearFlashSequence()
    end
  end

  lastHigh = highNow
end

local function updateColorFade(dt)
  if fadeDuration <= 0 then
    colorMix = targetColorMix
    return
  end

  local step = math.max(dt or 0, 0) / fadeDuration
  if colorMix < targetColorMix then
    colorMix = math.min(colorMix + step, targetColorMix)
  elseif colorMix > targetColorMix then
    colorMix = math.max(colorMix - step, targetColorMix)
  end
end

local function clearOutputs()
  electrics.values[whiteElectricName] = 0
  electrics.values[yellowElectricName] = 0
  electrics.values[fixedElectricName] = 0
  electrics.values[amberElectricName] = 0
end

local function reset()
  elapsedTime = 0
  clearFlashSequence()
  colorMix = 0
  targetColorMix = 0
  lastHigh = signalValue(flashSourceName) > 0.5
  clearOutputs()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  side = string.upper(tostring(jbeamData.side or side))
  mode = string.lower(tostring(jbeamData.mode or mode))
  brightness = clamp(tonumber(jbeamData.brightness) or brightness, 0, 1)
  whiteElectricName = jbeamData.whiteElectricName or ("sbrDRLWhite" .. side)
  yellowElectricName = jbeamData.yellowElectricName or ("sbrDRLYellow" .. side)
  fixedElectricName = jbeamData.fixedElectricName or ("sbrDRLFixed" .. side)
  amberElectricName = jbeamData.amberElectricName or ("sbrDRLAmber" .. side)
  flashSourceName = jbeamData.flashSourceName or flashSourceName
  flashRequired = math.max(1, math.floor(tonumber(jbeamData.flashRequired) or flashRequired))
  flashWindow = math.max(0.1, tonumber(jbeamData.flashWindow) or flashWindow)
  maxFlashGap = math.max(0.1, tonumber(jbeamData.maxFlashGap) or maxFlashGap)
  fadeDuration = math.max(0, tonumber(jbeamData.fadeDuration) or fadeDuration)
  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + math.max(dt or 0, 0)
  local running = clamp(signalValue("running"), 0, 1)
  local turnSignal = clamp(signalValue("signal_" .. side), 0, 1)
  local output = running * calibratedBrightness(brightness)

  if mode == "beamababa" then
    updateFlashToggle()
    updateColorFade(dt)
  end

  if turnSignal > 0.01 then
    electrics.values[whiteElectricName] = 0
    electrics.values[yellowElectricName] = 0
    electrics.values[fixedElectricName] = 0
    electrics.values[amberElectricName] = output * turnSignal
  elseif mode == "beamababa" then
    electrics.values[whiteElectricName] = output * (1 - colorMix)
    electrics.values[yellowElectricName] = output * colorMix
    electrics.values[fixedElectricName] = 0
    electrics.values[amberElectricName] = 0
  else
    electrics.values[whiteElectricName] = 0
    electrics.values[yellowElectricName] = 0
    electrics.values[fixedElectricName] = output
    electrics.values[amberElectricName] = 0
  end

  electrics.values["sbrDRLBeamABabaMix" .. side] = colorMix
  electrics.values["sbrDRLBeamABabaFlashCount" .. side] = flashCount
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
