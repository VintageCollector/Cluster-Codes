local M = {}

M.type = "auxiliary"

local abs = math.abs
local exp = math.exp
local max = math.max
local min = math.min
local rad = math.rad
local deg = math.deg
local asin = math.asin
local sqrt = math.sqrt
local stringFormat = string.format

local side = "R"
local lowElectricName = "bastionAFSLowR"
local highElectricName = "bastionAFSHighR"
local lowPropElectricName = nil
local highPropElectricName = nil
local lowSourceName = "lowhighbeam"
local highSourceName = "highbeam_wigwag_R"
local autoModeElectricName = nil

local autoLightsEnabled = true
local autoHighBeamEnabled = true
local keepLowBeamWithHigh = false
local autoLightNightStartHour = 18.5
local autoLightNightEndHour = 6.5
local autoLightOnLevel = 0.25
local autoLightOnDelay = 3.0
local autoLightOffLevel = 0.55
local autoLightSkyBrightnessReference = 25
local autoLightCoveredFactor = 0.12
local autoHighBeamMinSpeed = 7
local environmentPollInterval = 0.5
local trafficDetectionRange = 230
local trafficDetectionLateral = 8.2
local trafficDetectionNearLateral = 18
local trafficDetectionNearRange = 65
local trafficDetectionForwardSlack = 8
local trafficClearDelay = 0.75
local hidWarmupResponse = 0.75
local hidFadeOutResponse = 9
local hidWarmupFloor = 0.01
local hidWarmupEnabled = true
local startupPitchDown = -4.5
local startupPitchUp = 0
local startupPitchDownTime = 0.42
local startupPitchUpTime = 0.58
local startupPitchSettleTime = 2.15
local startupYawSweep = 8
local startupYawStartTime = 0.58
local startupYawLeftTime = 0.98
local startupYawRightTime = 1.16
local startupYawSettleTime = 1.62

local maxSwivelInside = 22
local maxSwivelOutside = 2.5
local maxLevelAngle = 5.5
local yawSign = 1
local pitchSign = 1
local yawResponse = 6.5
local steeringExpoCurve = 1.25
local levelResponse = 3.2
local baselineFollowRate = 0
local levelReferencePitchDeg = 0
local levelPitchGain = 0.85
local levelPitchDownGain = 0.12
local levelPitchUpGain = 0.14
local levelDownLimit = 1.0
local levelUpLimit = 0.9
local levelDeadzone = 0.05
local brakeDiveLift = 1.15
local brakeLevelMinSpeed = 1.5
local basePitchOffset = 0
local manualAimOffset = 0
local accelSquatDrop = 0
local accelPitchScale = 4
local accelThrottleWeight = 0.45
local accelLevelMinSpeed = 1
local accelLevelResponse = 8
local lowBeamRoll = 0
local highBeamRoll = 0
local adaptiveAimEnabled = true

local controlledProps = {}
local currentYaw = 0
local currentPitch = 0
local neutralPitch = nil
local startupTimer = 0
local startupAnimationActive = false
local lightsWereOn = false
local environmentTime = nil
local environmentLightLevel = nil
local lowLightActive = false
local lowLightActivationTimer = 0
local environmentPollTimer = 0
local autoSetLightsState = false
local flashAutoHoldTimer = 0
local flashAutoHoldDuration = 0.35
local trafficHoldTimer = 0
local hidWarmup = 0
local lastSpeed = nil
local accelLevel = 0

local function clamp(value, lower, upper)
  return min(max(value, lower), upper)
end

local function isAutoModeEnabled()
  if not autoModeElectricName or autoModeElectricName == "" then
    return true
  end

  local value = electrics.values[autoModeElectricName]
  if type(value) == "boolean" then
    return value
  end
  return (tonumber(value) or 0) > 0.5
end

local function lerp(a, b, t)
  return a + (b - a) * clamp(t, 0, 1)
end

local function smoothTowards(current, target, response, dt)
  return current + (target - current) * (1 - exp(-response * dt))
end

local function applySteeringExpo(value)
  local magnitude = abs(value)
  if magnitude <= 0 or steeringExpoCurve <= 0 then
    return value
  end

  local denominator = 1 - exp(-steeringExpoCurve)
  if denominator <= 0.0001 then
    return value
  end

  local curved = (1 - exp(-steeringExpoCurve * magnitude)) / denominator
  return value < 0 and -curved or curved
end
local function readPitch()
  if obj and obj.getDirectionVectorXYZ then
    local _, _, forwardZ = obj:getDirectionVectorXYZ()
    if forwardZ ~= nil then
      return asin(clamp(forwardZ, -1, 1))
    end
  end

  local _, pitch = obj:getRollPitchYawRad()
  return pitch or 0
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return ignitionLevel >= 1
  end

  return (electrics.values.engineRunning or 0) > 0 or (electrics.values.running or 0) > 0 or (electrics.values.ignition or 0) > 0
end

local function requestEnvironmentLight(dt)
  local sharedLight = electrics.values.bastionAFSEnvironmentLight
  if sharedLight ~= nil then
    environmentLightLevel = clamp(tonumber(sharedLight) or environmentLightLevel or 1, 0, 1.5)
  end

  environmentPollTimer = environmentPollTimer + max(dt or 0, 0)
  if environmentPollTimer < environmentPollInterval then
    return
  end

  environmentPollTimer = 0

  if obj and obj.queueGameEngineLua then
    local vehicleId = obj:getID()
    obj:queueGameEngineLua(
      stringFormat(
        "local veh=getObjectByID(%d); if veh then local fade=math.max(0.04,math.min(0.18,%0.3f/250)); local dayScale=math.max(0.5,math.min(1.5,%0.3f/25)); local daylight=dayScale; local state=core_environment and core_environment.getLightState and core_environment.getLightState(); if state then local night=state.isNight==true or state.nightLightsActive==true or tonumber(state.isNight)==1 or tonumber(state.nightLightsActive)==1; if night then daylight=0 elseif state.time~=nil and state.nightStart~=nil and state.nightEnd~=nil then local t=(tonumber(state.time) or 0)%%1; local function circularDistance(a,b) local d=math.abs(a-b)%%1; return math.min(d,1-d) end; local distance=math.min(circularDistance(t,(tonumber(state.nightStart) or 0)%%1),circularDistance(t,(tonumber(state.nightEnd) or 0)%%1)); daylight=dayScale*math.max(0,math.min(1,distance/fade)) end end; local cover=1; local p=veh:getPosition(); if p and vec3 then local start=p+vec3(0,0,1.8); local finish=p+vec3(0,0,80); local hit=nil; if castRay then hit=castRay(start,finish,true,true) elseif Engine and Engine.castRay then hit=Engine.castRay(start,finish,true,true) end; if hit then cover=%0.3f end end; local level=math.max(0,math.min(1.5,daylight*cover)); veh:queueLuaCommand('electrics.values.bastionAFSEnvironmentLight='..tostring(level)) end",
        vehicleId,
        autoLightSkyBrightnessReference,
        autoLightSkyBrightnessReference,
        autoLightCoveredFactor
      )
    )
  end
end

local function isLowLight(dt)
  local lightLevel = clamp(environmentLightLevel or 1, 0, 1.5)

  if lowLightActive then
    lowLightActivationTimer = 0
    if lightLevel > autoLightOffLevel then
      lowLightActive = false
    end
  elseif lightLevel < autoLightOnLevel then
    lowLightActivationTimer = lowLightActivationTimer + max(dt or 0, 0)
    if lowLightActivationTimer >= autoLightOnDelay then
      lowLightActive = true
      lowLightActivationTimer = 0
    end
  else
    lowLightActivationTimer = 0
  end

  electrics.values.bastionAFSAmbientLight = lightLevel
  return lowLightActive
end

local function trafficAheadNow()
  if not mapmgr or not mapmgr.getObjects or not obj then
    return false
  end

  local objects = mapmgr.getObjects()
  if not objects then
    return false
  end

  local myFront = obj:getFrontPosition()
  local myForward = vec3(obj:getDirectionVectorXYZ())
  local myUp = vec3(obj:getDirectionVectorUpXYZ())
  local myRight = vec3()
  myForward:normalize()
  myUp:normalize()
  myRight:setCross(myForward, myUp)
  myRight:normalize()

  for id, _ in pairs(objects) do
    if id ~= objectId then
      local otherPos = obj:getObjectCenterPosition(id)
      if otherPos then
        local rel = otherPos - myFront
        local forwardDist = rel:dot(myForward)
        local lateralDist = rel:dot(myRight)
        local planarDist = sqrt(forwardDist * forwardDist + lateralDist * lateralDist)
        local lateralLimit = trafficDetectionLateral + max(forwardDist, 0) * 0.018

        if planarDist < trafficDetectionNearRange then
          lateralLimit = max(lateralLimit, trafficDetectionNearLateral)
        end

        if forwardDist > -trafficDetectionForwardSlack and forwardDist < trafficDetectionRange and abs(lateralDist) < lateralLimit then
          return true
        end
      end
    end
  end

  return false
end

local function updateTrafficHold(dt)
  if trafficAheadNow() then
    trafficHoldTimer = trafficClearDelay
  else
    trafficHoldTimer = max(trafficHoldTimer - max(dt or 0, 0), 0)
  end

  return trafficHoldTimer > 0
end

local function updateAutomaticLighting(dt, ignitionPowered, speed, manualLowOutput, manualHighOutput)
  requestEnvironmentLight(dt)

  local autoModeEnabled = isAutoModeEnabled()
  local lowLightActive = autoModeEnabled and autoLightsEnabled and isLowLight(dt) and ignitionPowered
  local lightsState = electrics.values.lights_state or electrics.values.lights or 0

  local flashFlagActive = (electrics.values.bastionAFSFlashHighBeam or 0) > 0.01
  if flashFlagActive then
    flashAutoHoldTimer = flashAutoHoldDuration
  else
    flashAutoHoldTimer = max(flashAutoHoldTimer - max(dt or 0, 0), 0)
  end
  local flashHighBeamActive = flashFlagActive or flashAutoHoldTimer > 0

  if lowLightActive then
    if lightsState == 0 and electrics.setLightsState then
      electrics.setLightsState(1)
      autoSetLightsState = true
    end
  elseif autoSetLightsState then
    if lightsState ~= 0 and electrics.setLightsState then
      electrics.setLightsState(0)
    end
    autoSetLightsState = false
  end

  local trafficDetected = updateTrafficHold(dt)
  local highBeamArmed = manualHighOutput > 0.01
  local autoHighBeamAllowed = autoModeEnabled and autoHighBeamEnabled and (electrics.values.bastionAFSAutoHighBeamDisabled or 0) < 0.5
  local autoLowBeam = lowLightActive and (manualLowOutput <= 0.01 or highBeamArmed)
  local autoHighBeam = autoHighBeamAllowed and lowLightActive and highBeamArmed and speed >= autoHighBeamMinSpeed and not trafficDetected

  electrics.values.bastionAFSAutoLowBeam = autoLowBeam and 1 or 0
  electrics.values.bastionAFSAutoHighBeam = autoHighBeam and 1 or 0
  electrics.values.bastionAFSAutoHighBeamEnabled = autoHighBeamAllowed and 1 or 0
  electrics.values.bastionAFSHighBeamArmed = highBeamArmed and 1 or 0
  electrics.values.bastionAFSTrafficDetected = trafficDetected and 1 or 0
  electrics.values.bastionAFSAutoNight = lowLightActive and 1 or 0

  return autoLowBeam, autoHighBeam
end

local function controlledPropRole(prop)
  if prop.func == lowElectricName or prop.func == lowPropElectricName then
    return "low"
  end
  if prop.func == highElectricName or prop.func == highPropElectricName then
    return "high"
  end
  return nil
end

local function findControlledProps()
  controlledProps = {}
  for _, prop in pairs(v.data.props or {}) do
    local role = controlledPropRole(prop)
    if role and prop.rotation then
      controlledProps[#controlledProps + 1] = {
        prop = prop,
        role = role,
        baseX = prop.rotation.x or 0,
        baseY = prop.rotation.y or 0,
        baseZ = prop.rotation.z or 0
      }
    end
  end
end

local function applyAim(yawDegrees, pitchDegrees)
  local yawRadians = rad(yawDegrees * yawSign)
  local pitchRadians = rad(pitchDegrees * pitchSign)

  for _, controlled in ipairs(controlledProps) do
    local prop = controlled.prop
    -- SPOTLIGHT props point along local Y. Local X is pitch and local Z is yaw.
    -- Preserve the calibrated RealisticHeadlights rotation and add AFS motion.
    prop.rotation.x = controlled.baseX + pitchRadians
    prop.rotation.y = controlled.baseY + rad(controlled.role == "low" and lowBeamRoll or highBeamRoll)
    prop.rotation.z = controlled.baseZ + yawRadians
  end
end

local function startupPitchOffset()
  if startupTimer < startupPitchDownTime then
    return lerp(0, startupPitchDown, startupTimer / max(startupPitchDownTime, 0.001))
  elseif startupTimer < startupYawSettleTime then
    return startupPitchDown
  elseif startupTimer < startupPitchSettleTime then
    return lerp(startupPitchDown, 0, (startupTimer - startupYawSettleTime) / max(startupPitchSettleTime - startupYawSettleTime, 0.001))
  end
  return 0
end

local function startupYawOffset()
  local outwardYaw = side == "L" and startupYawSweep or -startupYawSweep
  if startupTimer < startupYawStartTime then
    return 0
  elseif startupTimer < startupYawLeftTime then
    return lerp(0, outwardYaw, (startupTimer - startupYawStartTime) / max(startupYawLeftTime - startupYawStartTime, 0.001))
  elseif startupTimer < startupYawRightTime then
    return outwardYaw
  elseif startupTimer < startupYawSettleTime then
    return lerp(outwardYaw, 0, (startupTimer - startupYawRightTime) / max(startupYawSettleTime - startupYawRightTime, 0.001))
  end
  return 0
end

local function updateGFX(dt)
  -- 0.39 assembles spotlight emitters as nested slots2 parts. Depending on
  -- part-load order they may not be present during controller init, so keep
  -- looking until the adaptive props have joined the assembled vehicle.
  if adaptiveAimEnabled and #controlledProps == 0 then
    findControlledProps()
  end
  local speed = abs(electrics.values.wheelspeed or electrics.values.airspeed or 0)
  local manualLowOutput = max(electrics.values[lowSourceName] or 0, electrics.values.lowbeam or 0)
  local highBeamFlashOutput = electrics.values.bastionAFSFlashHighBeam or 0
  local manualHighOutput = max(electrics.values[highSourceName] or 0, electrics.values.highbeam or 0, electrics.values.highbeam_filament or 0, highBeamFlashOutput)
  local ignitionPowered = isIgnitionPowered()
  local autoLowBeam, autoHighBeam = updateAutomaticLighting(dt, ignitionPowered, speed, manualLowOutput, manualHighOutput)
  local autoHighBeamAllowed = isAutoModeEnabled() and autoHighBeamEnabled and (electrics.values.bastionAFSAutoHighBeamDisabled or 0) < 0.5
  local lowOutput = max(manualLowOutput, autoLowBeam and 1 or 0)
  local highOutput = autoHighBeamAllowed and (autoHighBeam and 1 or 0) or manualHighOutput
  if highBeamFlashOutput > 0.01 then
    highOutput = max(highOutput, highBeamFlashOutput)
  end

  if not ignitionPowered then
    lowOutput = 0
    highOutput = 0
  end

  if highOutput > 0.01 then
    lowOutput = keepLowBeamWithHigh and max(lowOutput, highOutput) or 0
  end

  local lightsOn = lowOutput > 0.01 or highOutput > 0.01
  if hidWarmupEnabled then
    if lightsOn then
      hidWarmup = smoothTowards(hidWarmup, 1, hidWarmupResponse, dt)
      local warmupOutput = hidWarmupFloor + (1 - hidWarmupFloor) * hidWarmup
      lowOutput = lowOutput * warmupOutput
      highOutput = highOutput * warmupOutput
    else
      hidWarmup = 0
      lowOutput = 0
      highOutput = 0
    end
  else
    hidWarmup = targetWarmup
  end

  local pitch = readPitch()
  local gearIndex = electrics.values.gearIndex or 0
  local gearText = string.upper(tostring(electrics.values.gear or electrics.values.gearName or electrics.values.currentGear or electrics.values.gearboxMode or electrics.values.shifterPosition or ""))
  local startupGearAllowed = gearIndex == 0 or gearText == "P" or gearText == "N" or gearText == "PARK" or gearText == "NEUTRAL"
  local startupAnimationAllowed = speed < 0.45 and startupGearAllowed

  if neutralPitch == nil then
    neutralPitch = pitch
  end

  if lightsOn and not lightsWereOn then
    neutralPitch = pitch
    startupAnimationActive = startupAnimationAllowed
    startupTimer = startupAnimationActive and 0 or startupPitchSettleTime
  end

  if lightsOn then
    if startupAnimationActive and startupAnimationAllowed then
      startupTimer = startupTimer + dt
      if startupTimer >= startupPitchSettleTime then
        startupAnimationActive = false
      end
    else
      startupAnimationActive = false
      startupTimer = startupPitchSettleTime
    end
  else
    startupAnimationActive = false
    startupTimer = 0
    neutralPitch = smoothTowards(neutralPitch, pitch, 3, dt)
  end

  local steering = clamp(input.steering or electrics.values.steering_input or 0, -1, 1)

  local curveAssist = clamp((speed - 6.7) / 6.0, 0, 1)
  local expoSteering = applySteeringExpo(steering)
  local assistedSteering = expoSteering * (1 + curveAssist * 1.35 * (1 - abs(expoSteering)))
  local reverseReduction = gearIndex < 0 and 0 or 1
  local isInsideLamp = (side == "L" and steering < 0) or (side == "R" and steering > 0)
  local swivelLimit = isInsideLamp and maxSwivelInside or maxSwivelOutside
  local targetYaw = -assistedSteering * swivelLimit * reverseReduction
  targetYaw = targetYaw + startupYawOffset()

  local pitchErrorDeg = deg(pitch) - levelReferencePitchDeg
  if abs(pitchErrorDeg) < levelDeadzone then
    pitchErrorDeg = 0
  end

  local brakeInput = clamp(max(electrics.values.brake or 0, input.brake or 0), 0, 1)
  local brakeSpeedFactor = clamp(speed / max(brakeLevelMinSpeed, 0.001), 0, 1)
  brakeInput = brakeInput * brakeSpeedFactor
  local throttleInput = clamp(max(electrics.values.throttle or 0, input.throttle or 0), 0, 1)
  local accelFromSpeed = 0
  if lastSpeed ~= nil and dt > 0.0001 then
    accelFromSpeed = clamp(((speed - lastSpeed) / dt) / max(accelPitchScale, 0.001), 0, 1)
  end
  lastSpeed = speed
  local accelSpeedFactor = clamp(speed / max(accelLevelMinSpeed, 0.001), 0, 1)
  local accelInput = max(accelFromSpeed, throttleInput * accelThrottleWeight) * accelSpeedFactor
  accelLevel = smoothTowards(accelLevel, accelInput, accelLevelResponse, dt)

  local levelCorrection = 0
  if pitchErrorDeg > 0 then
    levelCorrection = -pitchErrorDeg * levelPitchDownGain
  elseif pitchErrorDeg < 0 then
    levelCorrection = -pitchErrorDeg * levelPitchUpGain
  end

  -- Positive projector pitch aims up. Braking gets explicit lift while
  -- acceleration/squat gets explicit drop so both transient cases react before
  -- the slower body-pitch signal fully settles.
  local targetPitch = basePitchOffset + manualAimOffset + clamp(levelCorrection + brakeInput * brakeDiveLift - accelLevel * accelSquatDrop, -levelDownLimit, levelUpLimit)
  targetPitch = targetPitch + startupPitchOffset()

  if not lightsOn then
    targetYaw = 0
    targetPitch = 0
  end

  currentYaw = smoothTowards(currentYaw, targetYaw, yawResponse * (1 + curveAssist * 1.1), dt)
  currentPitch = smoothTowards(currentPitch, targetPitch, levelResponse, dt)

  electrics.values[lowElectricName] = lowOutput
  electrics.values[highElectricName] = highOutput
  electrics.values.bastionAFSHIDWarmup = hidWarmup
  electrics.values["bastionAFSYaw" .. side] = currentYaw
  electrics.values["bastionAFSPitch" .. side] = currentPitch
  electrics.values["bastionAFSPitchError" .. side] = pitchErrorDeg
  electrics.values["bastionAFSLevelCorrection" .. side] = levelCorrection
  electrics.values["bastionAFSTargetPitch" .. side] = targetPitch
  electrics.values.bastionAFSBrakeLevel = brakeInput
  electrics.values.bastionAFSAccelLevel = accelLevel

  if adaptiveAimEnabled then
    applyAim(currentYaw, currentPitch)
  end
  lightsWereOn = lightsOn
end

local function reset()
  currentYaw = 0
  currentPitch = 0
  neutralPitch = readPitch()
  startupTimer = 0
  lightsWereOn = false
  startupAnimationActive = false
  environmentTime = nil
  environmentLightLevel = nil
  lowLightActive = false
  lowLightActivationTimer = 0
  environmentPollTimer = environmentPollInterval
  autoSetLightsState = false
  flashAutoHoldTimer = 0
  trafficHoldTimer = 0
  hidWarmup = 0
  lastSpeed = nil
  accelLevel = 0
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
  electrics.values.bastionAFSAutoLowBeam = 0
  electrics.values.bastionAFSAutoHighBeam = 0
  electrics.values.bastionAFSFlashHighBeam = 0
  electrics.values.bastionAFSHighBeamArmed = 0
  electrics.values.bastionAFSTrafficDetected = 0
  electrics.values.bastionAFSAutoNight = 0
  electrics.values.bastionAFSEnvironmentLight = 1
  electrics.values.bastionAFSAmbientLight = 1
  electrics.values.bastionAFSHIDWarmup = 0
  if adaptiveAimEnabled then
    applyAim(0, 0)
  end
end

local function initCoreConfig(jbeamData)
  side = jbeamData.side or side
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  lowPropElectricName = jbeamData.lowPropElectricName or lowElectricName
  highPropElectricName = jbeamData.highPropElectricName or highElectricName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  if jbeamData.autoModeElectricName ~= nil then autoModeElectricName = jbeamData.autoModeElectricName end
  maxSwivelInside = jbeamData.maxSwivelInside or maxSwivelInside
  maxSwivelOutside = jbeamData.maxSwivelOutside or maxSwivelOutside
  maxLevelAngle = jbeamData.maxLevelAngle or maxLevelAngle
  yawSign = jbeamData.yawSign or yawSign
  pitchSign = jbeamData.pitchSign or pitchSign
  yawResponse = jbeamData.yawResponse or yawResponse
  if jbeamData.steeringExpoCurve ~= nil then steeringExpoCurve = jbeamData.steeringExpoCurve end
  levelResponse = jbeamData.levelResponse or levelResponse
  baselineFollowRate = jbeamData.baselineFollowRate or baselineFollowRate
end

local function initLevelingConfig(jbeamData)
  if jbeamData.levelReferencePitchDeg ~= nil then levelReferencePitchDeg = jbeamData.levelReferencePitchDeg end
  if jbeamData.levelPitchGain ~= nil then levelPitchGain = jbeamData.levelPitchGain end
  if jbeamData.levelPitchDownGain ~= nil then levelPitchDownGain = jbeamData.levelPitchDownGain end
  if jbeamData.levelPitchUpGain ~= nil then levelPitchUpGain = jbeamData.levelPitchUpGain end
  if jbeamData.levelDownLimit ~= nil then levelDownLimit = jbeamData.levelDownLimit end
  if jbeamData.levelUpLimit ~= nil then levelUpLimit = jbeamData.levelUpLimit end
  if jbeamData.levelDeadzone ~= nil then levelDeadzone = jbeamData.levelDeadzone end
  if jbeamData.brakeDiveLift ~= nil then brakeDiveLift = jbeamData.brakeDiveLift end
  if jbeamData.brakeLevelMinSpeed ~= nil then brakeLevelMinSpeed = jbeamData.brakeLevelMinSpeed end
  if jbeamData.basePitchOffset ~= nil then basePitchOffset = jbeamData.basePitchOffset end
  if jbeamData.manualAimOffset ~= nil then manualAimOffset = tonumber(jbeamData.manualAimOffset) or manualAimOffset end
  if jbeamData.accelSquatDrop ~= nil then accelSquatDrop = jbeamData.accelSquatDrop end
  if jbeamData.accelPitchScale ~= nil then accelPitchScale = jbeamData.accelPitchScale end
  if jbeamData.accelThrottleWeight ~= nil then accelThrottleWeight = jbeamData.accelThrottleWeight end
  if jbeamData.accelLevelMinSpeed ~= nil then accelLevelMinSpeed = jbeamData.accelLevelMinSpeed end
  if jbeamData.accelLevelResponse ~= nil then accelLevelResponse = jbeamData.accelLevelResponse end
  lowBeamRoll = jbeamData.lowBeamRoll or lowBeamRoll
  highBeamRoll = jbeamData.highBeamRoll or highBeamRoll
  if jbeamData.adaptiveAimEnabled ~= nil then adaptiveAimEnabled = jbeamData.adaptiveAimEnabled end
end

local function initAutomaticLightingConfig(jbeamData)
  if jbeamData.autoLightsEnabled ~= nil then autoLightsEnabled = jbeamData.autoLightsEnabled end
  if jbeamData.autoHighBeamEnabled ~= nil then autoHighBeamEnabled = jbeamData.autoHighBeamEnabled end
  if jbeamData.keepLowBeamWithHigh ~= nil then keepLowBeamWithHigh = jbeamData.keepLowBeamWithHigh end
  if jbeamData.autoLightOnLevel ~= nil then autoLightOnLevel = jbeamData.autoLightOnLevel end
  if jbeamData.autoLightOnDelay ~= nil then autoLightOnDelay = max(tonumber(jbeamData.autoLightOnDelay) or autoLightOnDelay, 0) end
  if jbeamData.autoLightOffLevel ~= nil then autoLightOffLevel = jbeamData.autoLightOffLevel end
  if jbeamData.autoHighBeamMinSpeed ~= nil then autoHighBeamMinSpeed = jbeamData.autoHighBeamMinSpeed end
  if jbeamData.environmentPollInterval ~= nil then environmentPollInterval = jbeamData.environmentPollInterval end
  if jbeamData.trafficDetectionRange ~= nil then trafficDetectionRange = jbeamData.trafficDetectionRange end
  if jbeamData.trafficDetectionLateral ~= nil then trafficDetectionLateral = jbeamData.trafficDetectionLateral end
  if jbeamData.trafficDetectionNearLateral ~= nil then trafficDetectionNearLateral = jbeamData.trafficDetectionNearLateral end
  if jbeamData.trafficDetectionNearRange ~= nil then trafficDetectionNearRange = jbeamData.trafficDetectionNearRange end
  if jbeamData.trafficDetectionForwardSlack ~= nil then trafficDetectionForwardSlack = jbeamData.trafficDetectionForwardSlack end
  if jbeamData.trafficClearDelay ~= nil then trafficClearDelay = jbeamData.trafficClearDelay end
end

local function initWarmupConfig(jbeamData)
  hidWarmupEnabled = jbeamData.hidWarmupEnabled ~= false
  if jbeamData.hidWarmupResponse ~= nil then hidWarmupResponse = jbeamData.hidWarmupResponse end
  if jbeamData.hidFadeOutResponse ~= nil then hidFadeOutResponse = jbeamData.hidFadeOutResponse end
  if jbeamData.hidWarmupFloor ~= nil then hidWarmupFloor = jbeamData.hidWarmupFloor end
  if jbeamData.startupPitchDown ~= nil then startupPitchDown = jbeamData.startupPitchDown end
  if jbeamData.startupPitchDownTime ~= nil then startupPitchDownTime = jbeamData.startupPitchDownTime end
  if jbeamData.startupPitchSettleTime ~= nil then startupPitchSettleTime = jbeamData.startupPitchSettleTime end
  if jbeamData.startupYawSweep ~= nil then startupYawSweep = jbeamData.startupYawSweep end
  if jbeamData.startupYawStartTime ~= nil then startupYawStartTime = jbeamData.startupYawStartTime end
  if jbeamData.startupYawLeftTime ~= nil then startupYawLeftTime = jbeamData.startupYawLeftTime end
  if jbeamData.startupYawRightTime ~= nil then startupYawRightTime = jbeamData.startupYawRightTime end
  if jbeamData.startupYawSettleTime ~= nil then startupYawSettleTime = jbeamData.startupYawSettleTime end
end

local function init(jbeamData)
  initCoreConfig(jbeamData)
  initLevelingConfig(jbeamData)
  initAutomaticLightingConfig(jbeamData)
  initWarmupConfig(jbeamData)
  findControlledProps()
  if mapmgr and mapmgr.enableTracking then
    mapmgr.enableTracking()
  end
  reset()
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M



