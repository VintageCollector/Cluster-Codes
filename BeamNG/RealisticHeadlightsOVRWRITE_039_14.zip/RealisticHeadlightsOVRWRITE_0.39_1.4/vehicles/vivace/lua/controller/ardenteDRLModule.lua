local M = {}
M.type = "auxiliary"

local side = "R"
local mode = "factory"
local brightness = 0.5
local flashSourceName = "highbeam"
local flashRequired = 5
local flashWindow = 3
local maxFlashGap = 0.8
local fadeDuration = 1.25

local baseSwitches = {}
local segmentSwitches = {{}, {}, {}, {}, {}}
local elapsedTime = 0
local nextMaterialSearch = 0
local flashCount = 0
local sequenceStart = 0
local lastFlashTime = -1
local lastHigh = false
local colorMix = 0
local targetColorMix = 0

local fixedR = 255
local fixedG = 255
local fixedB = 255

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function calibratedBrightness(value)
  if value <= 0.5 then
    return value * 2
  end
  return 1 + (value - 0.5)
end

local function clearFlashSequence()
  flashCount = 0
  sequenceStart = 0
  lastFlashTime = -1
end

local function addUnique(list, seen, value)
  if value and value >= 0 and not seen[value] then
    list[#list + 1] = value
    seen[value] = true
  end
end

local function meshBelongsToSide(mesh)
  local meshName = tostring(mesh or "")
  return string.match(meshName, "_" .. side .. "$") ~= nil
end

local function findMaterialSwitches()
  baseSwitches = {}
  segmentSwitches = {{}, {}, {}, {}, {}}
  local baseSeen = {}
  local segmentSeen = {{}, {}, {}, {}, {}}
  local materialData = v.data._materials
  local triggers = materialData and materialData.triggers or {}

  for _, trigger in pairs(triggers) do
    local materialSwitch = tonumber(trigger.msc)
    if materialSwitch and meshBelongsToSide(trigger.mesh) then
      if trigger.orgMat == "ardente_drl" then
        addUnique(baseSwitches, baseSeen, materialSwitch)
      else
        for index = 1, 5 do
          if trigger.orgMat == "ardente_drl_signal_" .. side .. index then
            addUnique(segmentSwitches[index], segmentSeen[index], materialSwitch)
            break
          end
        end
      end
    end
  end
end

local function ensureMaterialSwitches()
  local found = #baseSwitches
  for index = 1, 5 do
    found = found + #segmentSwitches[index]
  end
  if found == 0 and elapsedTime >= nextMaterialSearch then
    findMaterialSwitches()
    nextMaterialSearch = elapsedTime + 0.5
  end
end

local function applySwitches(switches, intensity, red, green, blue)
  local scaled = math.max(intensity, 0)
  local output = color(red * scaled, green * scaled, blue * scaled)
  for _, materialSwitch in ipairs(switches) do
    obj:setMaterialEmissiveFactor(materialSwitch, output)
  end
end

local function updateFlashToggle()
  local highNow = signalValue(flashSourceName) > 0.5

  if flashCount > 0
    and (elapsedTime - sequenceStart > flashWindow
      or elapsedTime - lastFlashTime > maxFlashGap) then
    clearFlashSequence()
  end

  if highNow and not lastHigh then
    local sequenceExpired = flashCount == 0
      or elapsedTime - sequenceStart > flashWindow
      or elapsedTime - lastFlashTime > maxFlashGap

    if sequenceExpired then
      flashCount = 1
      sequenceStart = elapsedTime
    else
      flashCount = flashCount + 1
    end
    lastFlashTime = elapsedTime

    if flashCount >= flashRequired then
      targetColorMix = targetColorMix < 0.5 and 1 or 0
      clearFlashSequence()
    end
  end

  lastHigh = highNow
end

local function updateColorFade(dt)
  if fadeDuration <= 0 then
    colorMix = targetColorMix
    return
  end

  local step = math.max(dt or 0, 0) / fadeDuration
  if colorMix < targetColorMix then
    colorMix = math.min(colorMix + step, targetColorMix)
  elseif colorMix > targetColorMix then
    colorMix = math.max(colorMix - step, targetColorMix)
  end
end

local function reset()
  elapsedTime = 0
  nextMaterialSearch = 0
  clearFlashSequence()
  colorMix = 0
  targetColorMix = 0
  lastHigh = signalValue(flashSourceName) > 0.5
  findMaterialSwitches()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  side = string.upper(tostring(jbeamData.side or side))
  mode = string.lower(tostring(jbeamData.mode or mode))
  brightness = clamp(tonumber(jbeamData.brightness) or brightness, 0, 1)
  flashSourceName = jbeamData.flashSourceName or flashSourceName
  flashRequired = math.max(1, math.floor(tonumber(jbeamData.flashRequired) or flashRequired))
  flashWindow = math.max(0.1, tonumber(jbeamData.flashWindow) or flashWindow)
  maxFlashGap = math.max(0.1, tonumber(jbeamData.maxFlashGap) or maxFlashGap)
  fadeDuration = math.max(0, tonumber(jbeamData.fadeDuration) or fadeDuration)

  local fixedColor = type(jbeamData.fixedColor) == "table" and jbeamData.fixedColor or {}
  fixedR = clamp(tonumber(fixedColor.r) or fixedR, 0, 255)
  fixedG = clamp(tonumber(fixedColor.g) or fixedG, 0, 255)
  fixedB = clamp(tonumber(fixedColor.b) or fixedB, 0, 255)
  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + math.max(dt or 0, 0)
  if mode == "factory" then
    return
  end

  ensureMaterialSwitches()
  local running = clamp(math.max(signalValue("running"), signalValue("lowhighbeam")), 0, 1)
  local outputScale = calibratedBrightness(brightness)
  local selectedR = fixedR
  local selectedG = fixedG
  local selectedB = fixedB

  if mode == "beamababa" then
    updateFlashToggle()
    updateColorFade(dt)
    selectedR = 255
    selectedG = 255 * (1 - colorMix) + 255 * colorMix
    selectedB = 255 * (1 - colorMix)
  end

  applySwitches(baseSwitches, running * outputScale, selectedR, selectedG, selectedB)

  local turnSignal = signalValue("signal_" .. side) > 0.01
  for index = 1, 5 do
    if turnSignal then
      local segmentOutput = clamp(signalValue("signal_" .. side .. index), 0, 1)
      applySwitches(segmentSwitches[index], segmentOutput, 255, 140, 0)
    else
      applySwitches(
        segmentSwitches[index],
        running * outputScale,
        selectedR,
        selectedG,
        selectedB
      )
    end
  end

  electrics.values["ardenteDRLBeamABabaMix" .. side] = colorMix
  electrics.values["ardenteDRLBeamABabaFlashCount" .. side] = flashCount
  electrics.values["ardenteDRLOutput" .. side] = running * outputScale
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
