local M = {}
M.type = "auxiliary"

local side = "R"
local mode = "factory"
local brightness = 0.5
local whiteElectricName = "vivaceDRLWhiteR"
local yellowElectricName = "vivaceDRLYellowR"
local extraWhiteElectricName = "vivaceDRLExtraWhiteR"
local extraYellowElectricName = "vivaceDRLExtraYellowR"
local fixedElectricName = "vivaceDRLFixedR"
local flashSourceName = "highbeam"
local flashRequired = 5
local flashWindow = 3
local maxFlashGap = 0.8
local fadeDuration = 1.25

local materialTargets = {}
local materialSwitches = {}
local headlightMaterialSwitches = {}
local bumperMaterialSwitches = {}
local elapsedTime = 0
local nextMaterialSearch = 0
local flashCount = 0
local sequenceStart = 0
local lastFlashTime = -1
local lastHigh = false
local colorMix = 0
local targetColorMix = 0

local whiteR = 255
local whiteG = 255
local whiteB = 255
local yellowR = 255
local yellowG = 255
local yellowB = 0
local fixedR = 255
local fixedG = 255
local fixedB = 255
local amberR = 255
local amberG = 140
local amberB = 0
local hasBaseDRLEmitters = false
local hasFixedDRLEmitters = false

local function clamp(value, minimum, maximum)
  return math.max(minimum, math.min(maximum, value))
end

local function calibratedBrightness(value)
  if value <= 0.5 then
    return value * 2
  end
  return 1 + (value - 0.5)
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function clearFlashSequence()
  flashCount = 0
  sequenceStart = 0
  lastFlashTime = -1
end

local function configureMaterialTargets()
  local bumperSide = side == "R" and "FR" or "FL"
  materialTargets = {
    {material = "vivace_drl_signal_" .. side, mesh = "vivace_headlight_" .. side, targetType = "headlight"},
    {material = "vivace_drl", mesh = "tograc_headlight_" .. side, targetType = "headlight"},
    {material = "vivace_drl", mesh = "vivace_bumperskirtlight_b_" .. bumperSide, targetType = "bumper"},
    {material = "vivace_drl", mesh = "vivace_grille_wide_b_light_" .. side, targetType = "bumper"},
    {material = "vivace_drl", mesh = "tograc_bumperlight_" .. bumperSide, targetType = "bumper"},
  }
end

local function findMaterialSwitches()
  materialSwitches = {}
  headlightMaterialSwitches = {}
  bumperMaterialSwitches = {}
  local seenSwitches = {}
  local seenHeadlightSwitches = {}
  local seenBumperSwitches = {}
  local materialData = v.data._materials
  local triggers = materialData and materialData.triggers or {}

  for _, trigger in pairs(triggers) do
    local materialSwitch = tonumber(trigger.msc)
    if materialSwitch and materialSwitch >= 0 then
      for _, target in ipairs(materialTargets) do
        if trigger.orgMat == target.material and trigger.mesh == target.mesh then
          if not seenSwitches[materialSwitch] then
            materialSwitches[#materialSwitches + 1] = materialSwitch
            seenSwitches[materialSwitch] = true
          end
          if target.targetType == "headlight" and not seenHeadlightSwitches[materialSwitch] then
            headlightMaterialSwitches[#headlightMaterialSwitches + 1] = materialSwitch
            seenHeadlightSwitches[materialSwitch] = true
          elseif target.targetType == "bumper" and not seenBumperSwitches[materialSwitch] then
            bumperMaterialSwitches[#bumperMaterialSwitches + 1] = materialSwitch
            seenBumperSwitches[materialSwitch] = true
          end
          break
        end
      end
    end
  end
end

local function findBaseDRLEmitters()
  hasBaseDRLEmitters = false
  hasFixedDRLEmitters = false
  for _, prop in pairs(v.data.props or {}) do
    if prop.func == whiteElectricName then
      hasBaseDRLEmitters = true
    elseif prop.func == fixedElectricName then
      hasFixedDRLEmitters = true
    end
  end
end

local function updateFlashToggle()
  local highNow = signalValue(flashSourceName) > 0.5

  if flashCount > 0 and (elapsedTime - sequenceStart > flashWindow or elapsedTime - lastFlashTime > maxFlashGap) then
    clearFlashSequence()
  end

  if highNow and not lastHigh then
    local sequenceExpired = flashCount == 0
      or elapsedTime - sequenceStart > flashWindow
      or elapsedTime - lastFlashTime > maxFlashGap

    if sequenceExpired then
      flashCount = 1
      sequenceStart = elapsedTime
    else
      flashCount = flashCount + 1
    end
    lastFlashTime = elapsedTime

    if flashCount >= flashRequired then
      targetColorMix = targetColorMix < 0.5 and 1 or 0
      clearFlashSequence()
    end
  end

  lastHigh = highNow
end

local function updateColorFade(dt)
  if fadeDuration <= 0 then
    colorMix = targetColorMix
    return
  end

  local step = math.max(dt or 0, 0) / fadeDuration
  if colorMix < targetColorMix then
    colorMix = math.min(colorMix + step, targetColorMix)
  elseif colorMix > targetColorMix then
    colorMix = math.max(colorMix - step, targetColorMix)
  end
end

local function ensureMaterialSwitches()
  if #materialSwitches == 0 and elapsedTime >= nextMaterialSearch then
    findMaterialSwitches()
    nextMaterialSearch = elapsedTime + 0.5
  end
end

local function applyMaterialSwitches(switches, running, outputScale, colorR, colorG, colorB)
  local intensity = outputScale * running
  local red = colorR * intensity
  local green = colorG * intensity
  local blue = colorB * intensity

  for _, materialSwitch in ipairs(switches) do
    obj:setMaterialEmissiveFactor(materialSwitch, color(red, green, blue))
  end
end

local function applyDRLMaterial(running, outputScale, colorR, colorG, colorB)
  ensureMaterialSwitches()
  applyMaterialSwitches(materialSwitches, running, outputScale, colorR, colorG, colorB)
end

local function applyHeadlightDRLMaterial(running, outputScale, colorR, colorG, colorB)
  ensureMaterialSwitches()
  applyMaterialSwitches(headlightMaterialSwitches, running, outputScale, colorR, colorG, colorB)
end

local function applyBumperDRLMaterial(running, outputScale, colorR, colorG, colorB)
  ensureMaterialSwitches()
  applyMaterialSwitches(bumperMaterialSwitches, running, outputScale, colorR, colorG, colorB)
end

local function reset()
  elapsedTime = 0
  nextMaterialSearch = 0
  clearFlashSequence()
  colorMix = 0
  targetColorMix = 0
  lastHigh = signalValue(flashSourceName) > 0.5
  local running = clamp(signalValue("running"), 0, 1)
  local outputScale = calibratedBrightness(brightness)
  local extraOutput = running * math.max(outputScale - 1, 0)

  electrics.values[whiteElectricName] = mode == "factory" and running
    or mode == "beamababa" and running * outputScale
    or 0
  electrics.values[yellowElectricName] = 0
  electrics.values[extraWhiteElectricName] = mode == "beamababa" and extraOutput or 0
  electrics.values[extraYellowElectricName] = 0
  electrics.values[fixedElectricName] = mode == "fixed"
    and (hasFixedDRLEmitters and running * outputScale or extraOutput)
    or 0
  electrics.values["vivaceDRLBeamABabaMix" .. side] = 0
  electrics.values["vivaceDRLBeamABabaFlashCount" .. side] = 0
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  side = string.upper(tostring(jbeamData.side or side))
  mode = string.lower(tostring(jbeamData.mode or mode))
  brightness = clamp(tonumber(jbeamData.brightness) or brightness, 0, 1)
  whiteElectricName = jbeamData.whiteElectricName or ("vivaceDRLWhite" .. side)
  yellowElectricName = jbeamData.yellowElectricName or ("vivaceDRLYellow" .. side)
  extraWhiteElectricName = "vivaceDRLExtraWhite" .. side
  extraYellowElectricName = "vivaceDRLExtraYellow" .. side
  fixedElectricName = jbeamData.fixedElectricName or ("vivaceDRLFixed" .. side)
  local fixedColor = type(jbeamData.fixedColor) == "table" and jbeamData.fixedColor or {}
  fixedR = clamp(tonumber(fixedColor.r) or fixedR, 0, 255)
  fixedG = clamp(tonumber(fixedColor.g) or fixedG, 0, 255)
  fixedB = clamp(tonumber(fixedColor.b) or fixedB, 0, 255)
  flashSourceName = jbeamData.flashSourceName or flashSourceName
  flashRequired = math.max(1, math.floor(tonumber(jbeamData.flashRequired) or flashRequired))
  flashWindow = math.max(0.1, tonumber(jbeamData.flashWindow) or flashWindow)
  maxFlashGap = math.max(0.1, tonumber(jbeamData.maxFlashGap) or maxFlashGap)
  fadeDuration = math.max(0, tonumber(jbeamData.fadeDuration) or fadeDuration)
  configureMaterialTargets()
  findMaterialSwitches()
  findBaseDRLEmitters()
  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + math.max(dt or 0, 0)
  local running = clamp(signalValue("running"), 0, 1)
  local turnSignal = clamp(signalValue("signal_" .. side), 0, 1)
  local outputScale = calibratedBrightness(brightness)
  local extraOutput = running * math.max(outputScale - 1, 0)
  local selectedR = fixedR
  local selectedG = fixedG
  local selectedB = fixedB

  if mode == "beamababa" then
    updateFlashToggle()
    updateColorFade(dt)
    selectedR = whiteR + (yellowR - whiteR) * colorMix
    selectedG = whiteG + (yellowG - whiteG) * colorMix
    selectedB = whiteB + (yellowB - whiteB) * colorMix
  end

  if mode ~= "factory" and turnSignal > 0.01 then
    applyBumperDRLMaterial(running, outputScale, selectedR, selectedG, selectedB)
    applyHeadlightDRLMaterial(turnSignal, 1, amberR, amberG, amberB)
    electrics.values[whiteElectricName] = 0
    electrics.values[yellowElectricName] = 0
    electrics.values[extraWhiteElectricName] = 0
    electrics.values[extraYellowElectricName] = 0
    electrics.values[fixedElectricName] = 0
  elseif mode == "beamababa" then
    applyDRLMaterial(running, outputScale, selectedR, selectedG, selectedB)
    electrics.values[whiteElectricName] = running * outputScale * (1 - colorMix)
    electrics.values[yellowElectricName] = running * outputScale * colorMix
    electrics.values[extraWhiteElectricName] = extraOutput * (1 - colorMix)
    electrics.values[extraYellowElectricName] = extraOutput * colorMix
    electrics.values[fixedElectricName] = 0
  elseif mode == "fixed" then
    applyDRLMaterial(running, outputScale, fixedR, fixedG, fixedB)
    electrics.values[whiteElectricName] = 0
    electrics.values[yellowElectricName] = 0
    electrics.values[extraWhiteElectricName] = 0
    electrics.values[extraYellowElectricName] = 0
    electrics.values[fixedElectricName] = hasFixedDRLEmitters and running * outputScale or extraOutput
  else
    electrics.values[whiteElectricName] = running
    electrics.values[yellowElectricName] = 0
    electrics.values[extraWhiteElectricName] = 0
    electrics.values[extraYellowElectricName] = 0
    electrics.values[fixedElectricName] = 0
  end

  electrics.values["vivaceDRLBeamABabaMix" .. side] = colorMix
  electrics.values["vivaceDRLBeamABabaFlashCount" .. side] = flashCount
  electrics.values["vivaceDRLBeamABabaOutput" .. side] = outputScale
  electrics.values["vivaceDRLFixedHasBaseEmitters" .. side] = hasBaseDRLEmitters and 1 or 0
  electrics.values["vivaceDRLFixedHasColorEmitters" .. side] = hasFixedDRLEmitters and 1 or 0
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
