local M = {}

M.type = "auxiliary"

local max = math.max

local lowElectricName = "bastionProjectorLowR"
local highElectricName = "bastionProjectorHighR"
local combinedElectricName = "bastionProjectorOnR"
local lowSourceName = "lowbeam"
local highSourceName = "highbeam_wigwag_R"
local keepLowBeamWithHigh = false

local function reset()
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
  electrics.values[combinedElectricName] = 0
end

local function init(jbeamData)
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  combinedElectricName = jbeamData.combinedElectricName or combinedElectricName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  if jbeamData.keepLowBeamWithHigh ~= nil then keepLowBeamWithHigh = jbeamData.keepLowBeamWithHigh end
  reset()
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return ignitionLevel >= 1
  end

  return (electrics.values.engineRunning or 0) > 0
    or (electrics.values.running or 0) > 0
    or (electrics.values.ignition or 0) > 0
end

local function updateGFX()
  if not isIgnitionPowered() then
    reset()
    return
  end

  local highOutput = max(electrics.values[highSourceName] or 0, electrics.values.highbeam or 0)
  local lowOutput = max(electrics.values[lowSourceName] or 0, electrics.values.lowbeam or 0)
  if highOutput > 0.01 then
    lowOutput = keepLowBeamWithHigh and max(lowOutput, highOutput) or 0
  end

  electrics.values[lowElectricName] = lowOutput
  electrics.values[highElectricName] = highOutput
  electrics.values[combinedElectricName] = max(lowOutput, highOutput)
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
