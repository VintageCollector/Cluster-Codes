local M = {}
M.type = "auxiliary"

local max = math.max
local min = math.min

local dimFactor = 0.2
local fadeRate = 6
local currentFactor = 1
local elapsedTime = 0
local nextMaterialSearch = 0
local materialSwitches = {}
local targetMaterials = {}
local outputElectricName = "rhCabinDisplayBrightness"
local headlightSources = {
  "lowhighbeam",
  "lowbeam",
}

local function clamp(value, minimum, maximum)
  return min(max(value, minimum), maximum)
end

local function configureTargetMaterials(materialNames)
  targetMaterials = {}
  if type(materialNames) ~= "table" then
    return
  end

  for key, value in pairs(materialNames) do
    if type(value) == "string" then
      targetMaterials[value] = true
    elseif type(key) == "string" and value then
      targetMaterials[key] = true
    end
  end
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function findMaterialSwitches()
  materialSwitches = {}
  local seen = {}
  local materialData = v.data._materials
  local triggers = materialData and materialData.triggers or {}

  for _, trigger in pairs(triggers) do
    local materialSwitch = tonumber(trigger.msc)
    if materialSwitch and materialSwitch >= 0 and targetMaterials[trigger.orgMat] then
      if not seen[materialSwitch] then
        materialSwitches[#materialSwitches + 1] = materialSwitch
        seen[materialSwitch] = true
      end
    end
  end
end

local function headlightsOn()
  local output = 0
  for _, sourceName in ipairs(headlightSources) do
    output = max(output, signalValue(sourceName))
  end
  return output > 0.01
end

local function applyBrightness()
  local channel = 255 * currentFactor
  local output = color(channel, channel, channel)
  for _, materialSwitch in ipairs(materialSwitches) do
    obj:setMaterialEmissiveFactor(materialSwitch, output)
  end
end

local function reset()
  elapsedTime = 0
  nextMaterialSearch = 0
  currentFactor = headlightsOn() and dimFactor or 1
  findMaterialSwitches()
  applyBrightness()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  dimFactor = clamp(tonumber(jbeamData.dimFactor) or 0.2, 0.05, 1)
  fadeRate = max(tonumber(jbeamData.fadeRate) or 6, 0)
  outputElectricName = jbeamData.outputElectricName or "rhCabinDisplayBrightness"
  if type(jbeamData.headlightSources) == "table" then
    headlightSources = jbeamData.headlightSources
  end
  configureTargetMaterials(jbeamData.targetMaterials)
  reset()
end

local function updateGFX(dt)
  elapsedTime = elapsedTime + max(dt or 0, 0)
  if #materialSwitches == 0 and elapsedTime >= nextMaterialSearch then
    findMaterialSwitches()
    nextMaterialSearch = elapsedTime + 0.5
  end

  local targetFactor = headlightsOn() and dimFactor or 1
  local blend = min(max(dt or 0, 0) * fadeRate, 1)
  currentFactor = currentFactor + (targetFactor - currentFactor) * blend
  if math.abs(currentFactor - targetFactor) < 0.001 then
    currentFactor = targetFactor
  end
  applyBrightness()

  electrics.values[outputElectricName] = currentFactor
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
