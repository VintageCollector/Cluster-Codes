local M = {}

M.type = "auxiliary"

local outputName = "rhRoamerDrlEnabledR"
local enabled = true

local function writeOutput()
  electrics.values[outputName] = enabled and 1 or 0
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  outputName = jbeamData.outputName or outputName
  enabled = jbeamData.enabled ~= false
  writeOutput()
end

local function reset()
  writeOutput()
end

local function updateGFX()
  writeOutput()
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
