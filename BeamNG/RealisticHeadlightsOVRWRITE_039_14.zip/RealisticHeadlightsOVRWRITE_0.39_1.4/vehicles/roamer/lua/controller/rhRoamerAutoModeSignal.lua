local M = {}

M.type = "auxiliary"

local electricName = "rhRoamerAutoModeR"
local value = 0

local function writeOutput()
  electrics.values[electricName] = value
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  electricName = jbeamData.electricName or electricName
  value = tonumber(jbeamData.value) or 0
  writeOutput()
end

M.init = init
M.reset = writeOutput
M.updateGFX = writeOutput

return M
