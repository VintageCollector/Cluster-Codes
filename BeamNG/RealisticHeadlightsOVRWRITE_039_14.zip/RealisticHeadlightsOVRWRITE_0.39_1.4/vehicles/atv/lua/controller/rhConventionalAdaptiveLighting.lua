local M = {}

M.type = "auxiliary"

local abs = math.abs
local max = math.max
local min = math.min
local sqrt = math.sqrt
local stringFormat = string.format

local lowElectricName = "rhConventionalAutoLow"
local highElectricName = "rhConventionalAutoHigh"
local highSourceName = "highbeam"
local highSideSourceName = ""
local environmentElectricName = "rhConventionalEnvironmentLight"
local keepLowBeamWithHigh = false
local autoLightOnLevel = 0.25
local autoLightOnDelay = 3.0
local autoLightOffLevel = 0.55
local autoLightSkyBrightnessReference = 25
local autoLightCoveredFactor = 0.12
local autoHighBeamMinSpeed = 7
local environmentPollInterval = 0.5
local trafficDetectionRange = 230
local trafficDetectionLateral = 8.2
local trafficDetectionNearLateral = 18
local trafficDetectionNearRange = 65
local trafficDetectionForwardSlack = 8
local trafficClearDelay = 0.75

local environmentLightLevel = nil
local environmentPollTimer = 0
local lowLightActive = false
local lowLightActivationTimer = 0
local trafficHoldTimer = 0
local autoSetLightsState = false

local function clamp(value, minimum, maximum)
  return min(max(value, minimum), maximum)
end

local function signalValue(name)
  if not name or name == "" then
    return 0
  end
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return (tonumber(ignitionLevel) or 0) >= 1
  end
  return signalValue("engineRunning") > 0 or signalValue("ignition") > 0
end

local function clearOutputs()
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
end

local function requestEnvironmentLight(dt)
  local sharedLight = electrics.values[environmentElectricName]
  if sharedLight ~= nil then
    environmentLightLevel = clamp(tonumber(sharedLight) or environmentLightLevel or 1, 0, 1.5)
  end

  environmentPollTimer = environmentPollTimer + max(dt or 0, 0)
  if environmentPollTimer < environmentPollInterval then
    return
  end
  environmentPollTimer = 0

  if obj and obj.queueGameEngineLua then
    local vehicleId = obj:getID()
    obj:queueGameEngineLua(
      stringFormat(
        "local veh=getObjectByID(%d); if veh then local fade=math.max(0.04,math.min(0.18,%0.3f/250)); local dayScale=math.max(0.5,math.min(1.5,%0.3f/25)); local daylight=dayScale; local state=core_environment and core_environment.getLightState and core_environment.getLightState(); if state then local night=state.isNight==true or state.nightLightsActive==true or tonumber(state.isNight)==1 or tonumber(state.nightLightsActive)==1; if night then daylight=0 elseif state.time~=nil and state.nightStart~=nil and state.nightEnd~=nil then local t=(tonumber(state.time) or 0)%%1; local function circularDistance(a,b) local d=math.abs(a-b)%%1; return math.min(d,1-d) end; local distance=math.min(circularDistance(t,(tonumber(state.nightStart) or 0)%%1),circularDistance(t,(tonumber(state.nightEnd) or 0)%%1)); daylight=dayScale*math.max(0,math.min(1,distance/fade)) end end; local cover=1; local p=veh:getPosition(); if p and vec3 then local start=p+vec3(0,0,1.8); local finish=p+vec3(0,0,80); local hit=nil; if castRay then hit=castRay(start,finish,true,true) elseif Engine and Engine.castRay then hit=Engine.castRay(start,finish,true,true) end; if hit then cover=%0.3f end end; local level=math.max(0,math.min(1.5,daylight*cover)); veh:queueLuaCommand('electrics.values[%q]='..tostring(level)) end",
        vehicleId,
        autoLightSkyBrightnessReference,
        autoLightSkyBrightnessReference,
        autoLightCoveredFactor,
        environmentElectricName
      )
    )
  end
end

local function isLowLight(dt)
  local level = clamp(environmentLightLevel or 1, 0, 1.5)
  if lowLightActive then
    lowLightActivationTimer = 0
    if level > autoLightOffLevel then
      lowLightActive = false
    end
  elseif level < autoLightOnLevel then
    lowLightActivationTimer = lowLightActivationTimer + max(dt or 0, 0)
    if lowLightActivationTimer >= autoLightOnDelay then
      lowLightActive = true
      lowLightActivationTimer = 0
    end
  else
    lowLightActivationTimer = 0
  end
  return lowLightActive
end

local function trafficAheadNow()
  if not mapmgr or not mapmgr.getObjects or not obj then
    return false
  end
  local objects = mapmgr.getObjects()
  if not objects then
    return false
  end

  local myFront = obj:getFrontPosition()
  local myForward = vec3(obj:getDirectionVectorXYZ())
  local myUp = vec3(obj:getDirectionVectorUpXYZ())
  local myRight = vec3()
  myForward:normalize()
  myUp:normalize()
  myRight:setCross(myForward, myUp)
  myRight:normalize()

  for id, _ in pairs(objects) do
    if id ~= objectId then
      local otherPos = obj:getObjectCenterPosition(id)
      if otherPos then
        local relative = otherPos - myFront
        local forwardDistance = relative:dot(myForward)
        local lateralDistance = relative:dot(myRight)
        local planarDistance = sqrt(
          forwardDistance * forwardDistance + lateralDistance * lateralDistance
        )
        local lateralLimit = trafficDetectionLateral + max(forwardDistance, 0) * 0.018
        if planarDistance < trafficDetectionNearRange then
          lateralLimit = max(lateralLimit, trafficDetectionNearLateral)
        end
        if forwardDistance > -trafficDetectionForwardSlack
          and forwardDistance < trafficDetectionRange
          and abs(lateralDistance) < lateralLimit then
          return true
        end
      end
    end
  end
  return false
end

local function trafficAhead(dt)
  if trafficAheadNow() then
    trafficHoldTimer = trafficClearDelay
  else
    trafficHoldTimer = max(trafficHoldTimer - max(dt or 0, 0), 0)
  end
  return trafficHoldTimer > 0
end

local function releaseAutomaticLightState()
  if autoSetLightsState then
    local lightsState = electrics.values.lights_state or electrics.values.lights or 0
    if lightsState ~= 0 and electrics.setLightsState then
      electrics.setLightsState(0)
    end
    autoSetLightsState = false
  end
end

local function updateGFX(dt)
  if not isIgnitionPowered() then
    clearOutputs()
    releaseAutomaticLightState()
    return
  end

  requestEnvironmentLight(dt)
  local dark = isLowLight(dt)
  local lightsState = electrics.values.lights_state or electrics.values.lights or 0
  if dark and lightsState == 0 and electrics.setLightsState then
    electrics.setLightsState(1)
    autoSetLightsState = true
  elseif not dark then
    releaseAutomaticLightState()
  end

  local highArmed = max(
    signalValue(highSourceName),
    signalValue(highSideSourceName),
    signalValue("highbeam")
  ) > 0.01
  local flashActive = signalValue("rhFlashHighBeam") > 0.01
  local speed = abs(electrics.values.wheelspeed or electrics.values.airspeed or 0)
  local highActive = flashActive
    or (
      dark
      and highArmed
      and speed >= autoHighBeamMinSpeed
      and not trafficAhead(dt)
    )

  electrics.values[highElectricName] = highActive and 1 or 0
  electrics.values[lowElectricName] = dark
    and (keepLowBeamWithHigh or not highActive)
    and 1
    or 0
end

local function reset()
  environmentLightLevel = nil
  environmentPollTimer = environmentPollInterval
  lowLightActive = false
  lowLightActivationTimer = 0
  trafficHoldTimer = 0
  autoSetLightsState = false
  clearOutputs()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  highSourceName = jbeamData.highSourceName or highSourceName
  highSideSourceName = jbeamData.highSideSourceName or highSideSourceName
  environmentElectricName = jbeamData.environmentElectricName or environmentElectricName
  if jbeamData.keepLowBeamWithHigh ~= nil then keepLowBeamWithHigh = jbeamData.keepLowBeamWithHigh end
  if jbeamData.autoLightOnLevel ~= nil then autoLightOnLevel = jbeamData.autoLightOnLevel end
  if jbeamData.autoLightOnDelay ~= nil then autoLightOnDelay = max(tonumber(jbeamData.autoLightOnDelay) or autoLightOnDelay, 0) end
  if jbeamData.autoLightOffLevel ~= nil then autoLightOffLevel = jbeamData.autoLightOffLevel end
  if jbeamData.autoHighBeamMinSpeed ~= nil then autoHighBeamMinSpeed = jbeamData.autoHighBeamMinSpeed end
  if jbeamData.environmentPollInterval ~= nil then environmentPollInterval = jbeamData.environmentPollInterval end
  if jbeamData.trafficDetectionRange ~= nil then trafficDetectionRange = jbeamData.trafficDetectionRange end
  if jbeamData.trafficDetectionLateral ~= nil then trafficDetectionLateral = jbeamData.trafficDetectionLateral end
  if jbeamData.trafficDetectionNearLateral ~= nil then trafficDetectionNearLateral = jbeamData.trafficDetectionNearLateral end
  if jbeamData.trafficDetectionNearRange ~= nil then trafficDetectionNearRange = jbeamData.trafficDetectionNearRange end
  if jbeamData.trafficDetectionForwardSlack ~= nil then trafficDetectionForwardSlack = jbeamData.trafficDetectionForwardSlack end
  if jbeamData.trafficClearDelay ~= nil then trafficClearDelay = jbeamData.trafficClearDelay end
  if mapmgr and mapmgr.enableTracking then
    mapmgr.enableTracking()
  end
  reset()
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
