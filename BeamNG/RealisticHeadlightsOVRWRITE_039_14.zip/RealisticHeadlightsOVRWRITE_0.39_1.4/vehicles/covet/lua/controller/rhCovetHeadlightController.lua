local M = {}

M.type = "auxiliary"

local exp = math.exp
local max = math.max
local min = math.min

local mode = "halogen"
local lowElectricName = "rhRoamerPreHalogenLowR"
local highElectricName = "rhRoamerPreHalogenHighR"
local drlElectricName = "rhRoamerPreHalogenDrlR"
local drlEnableElectricName = "rhRoamerDrlEnabledR"
local autoLowElectricName = "rhRoamerAutoLowR"
local autoHighElectricName = "rhRoamerAutoHighR"
local autoModeElectricName = "rhRoamerAutoModeR"
local lowHighSourceName = "lowhighbeam"
local lowSourceName = "lowbeam"
local highSourceName = "highbeam_wigwag_R"
local drlLevel = 0.5
local highSwitchThreshold = 0.5
local hidWarmupResponse = 0.75
local hidFadeOutResponse = 9
local hidWarmupFloor = 0.01
local hidWarmup = 0

local function clamp(value, minimum, maximum)
  return max(minimum, min(maximum, value))
end

local function signalValue(name)
  local value = electrics.values[name]
  if type(value) == "boolean" then
    return value and 1 or 0
  end
  return tonumber(value) or 0
end

local function isDrlEnabled()
  local value = electrics.values[drlEnableElectricName]
  if value == nil then
    return true
  end
  if type(value) == "boolean" then
    return value
  end
  return (tonumber(value) or 0) > 0.5
end

local function smoothTowards(current, target, response, dt)
  return current + (target - current) * (1 - exp(-response * dt))
end

local function isIgnitionPowered()
  local ignitionLevel = electrics.values.ignitionLevel
  if ignitionLevel ~= nil then
    return (tonumber(ignitionLevel) or 0) >= 1
  end

  return signalValue("engineRunning") > 0 or signalValue("ignition") > 0
end

local function clearOutputs()
  electrics.values[lowElectricName] = 0
  electrics.values[highElectricName] = 0
  electrics.values[drlElectricName] = 0
end

local function reset()
  hidWarmup = 0
  clearOutputs()
end

local function init(jbeamData)
  jbeamData = jbeamData or {}
  mode = string.lower(tostring(jbeamData.mode or mode))
  lowElectricName = jbeamData.lowElectricName or lowElectricName
  highElectricName = jbeamData.highElectricName or highElectricName
  drlElectricName = jbeamData.drlElectricName or drlElectricName
  drlEnableElectricName = jbeamData.drlEnableElectricName or drlEnableElectricName
  autoLowElectricName = jbeamData.autoLowElectricName or autoLowElectricName
  autoHighElectricName = jbeamData.autoHighElectricName or autoHighElectricName
  autoModeElectricName = jbeamData.autoModeElectricName or autoModeElectricName
  lowHighSourceName = jbeamData.lowHighSourceName or lowHighSourceName
  lowSourceName = jbeamData.lowSourceName or lowSourceName
  highSourceName = jbeamData.highSourceName or highSourceName
  drlLevel = clamp(tonumber(jbeamData.drlLevel) or drlLevel, 0, 1)
  highSwitchThreshold = clamp(
    tonumber(jbeamData.highSwitchThreshold) or highSwitchThreshold,
    0,
    1
  )
  hidWarmupResponse = max(0, tonumber(jbeamData.hidWarmupResponse) or hidWarmupResponse)
  hidFadeOutResponse = max(0, tonumber(jbeamData.hidFadeOutResponse) or hidFadeOutResponse)
  hidWarmupFloor = clamp(tonumber(jbeamData.hidWarmupFloor) or hidWarmupFloor, 0, 1)
  reset()
end

local function updateWarmup(demand, dt)
  local active = demand > 0.01
  if not active then
    hidWarmup = 0
    return 0
  end

  hidWarmup = smoothTowards(hidWarmup, 1, hidWarmupResponse, max(dt or 0, 0))
  return hidWarmupFloor + (1 - hidWarmupFloor) * hidWarmup
end

local function updateGFX(dt)
  if not isIgnitionPowered() then
    reset()
    return
  end

  local autoLowInput = clamp(signalValue(autoLowElectricName), 0, 1)
  local autoHighInput = clamp(signalValue(autoHighElectricName), 0, 1)
  local lowHighInput = clamp(signalValue(lowHighSourceName), 0, 1)
  local lowInput = clamp(signalValue(lowSourceName), 0, 1)
  local highInput = clamp(max(signalValue(highSourceName), signalValue("highbeam")), 0, 1)
  if signalValue(autoModeElectricName) > 0.5 then
    lowHighInput = autoLowInput
    lowInput = autoLowInput
    highInput = autoHighInput
  end
  local highMode = highInput > highSwitchThreshold
  local lowModeInput = highMode and 0 or max(lowInput, lowHighInput)
  local headlightsOn = max(lowHighInput, lowInput, highInput) > 0.01
  local drlEnabled = isDrlEnabled()
  local drlOutput = drlEnabled and not headlightsOn and drlLevel or 0

  if mode == "xenonseparate" then
    local xenonLowInput = max(lowInput, lowHighInput, highInput)
    local warmupOutput = updateWarmup(xenonLowInput, dt)
    electrics.values[lowElectricName] = xenonLowInput * warmupOutput
    electrics.values[highElectricName] = highInput
  elseif mode == "xenonbi" then
    local warmupOutput = updateWarmup(max(lowModeInput, highInput), dt)
    electrics.values[lowElectricName] = highMode and 0 or lowModeInput * warmupOutput
    electrics.values[highElectricName] = highMode and highInput * warmupOutput or 0
  else
    hidWarmup = 0
    electrics.values[lowElectricName] = lowModeInput
    electrics.values[highElectricName] = highInput
  end

  electrics.values[drlElectricName] = drlOutput
end

M.init = init
M.reset = reset
M.updateGFX = updateGFX

return M
