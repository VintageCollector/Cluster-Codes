load("zeit_customLightFlares")
registerCoreModule("zeit/customLightFlares")