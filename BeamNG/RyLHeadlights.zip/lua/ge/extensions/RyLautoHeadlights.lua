local M = {}

local CHECK_INTERVAL = 1
local SPAWN_DELAY = 0.5

local sunset = 0.3576
local sunrise = 0.75

local timer = 0
local lastNightState = nil

local knownVehicles = {}
local pendingVehicles = {}

local function isNightTime()
  local tod = core_environment.getTimeOfDay()

  if not tod or tod.time == nil then
    return nil
  end

  local time = tod.time

  return time >= sunset and time < sunrise
end

local function setVehicleHeadlights(vehicle, night)
  if not vehicle then return end

  vehicle:queueLuaCommand(
    night and "electrics.setLightsState(1)"
          or "electrics.setLightsState(0)"
  )
end

local function scheduleVehicleUpdate(vehicleID)
  if vehicleID == nil then return end

  pendingVehicles[vehicleID] = SPAWN_DELAY

  log("I", "autoHeadlights",
    "Scheduled headlight update for vehicle " .. tostring(vehicleID))
end

local function updateHeadlights()
  local night = isNightTime()

  if night == nil then return end

  local stateChanged = night ~= lastNightState
  local vehicles = getAllVehicles()
  local currentVehicles = {}

  for _, vehicle in ipairs(vehicles) do
    local vehicleID = vehicle:getID()

    currentVehicles[vehicleID] = true

    if not knownVehicles[vehicleID] then
      scheduleVehicleUpdate(vehicleID)
    end

    if stateChanged then
      setVehicleHeadlights(vehicle, night)
    end
  end

  knownVehicles = currentVehicles

  if stateChanged then
    lastNightState = night

    log("I", "autoHeadlights",
      night and "Night detected - headlights ON"
            or "Day detected - headlights OFF")
  end
end

local function onVehicleSpawned(vehicleID)
  scheduleVehicleUpdate(vehicleID)
end

local function onVehicleResetted(vehicleID)
  scheduleVehicleUpdate(vehicleID)
end

local function onVehicleReset(vehicleID)
  scheduleVehicleUpdate(vehicleID)
end

local function onVehicleDestroyed(vehicleID)
  knownVehicles[vehicleID] = nil
  pendingVehicles[vehicleID] = nil
end

local function onUpdate(dtReal, dtSim, dtRaw)
  timer = timer + dtReal

  if timer >= CHECK_INTERVAL then
    timer = 0
    updateHeadlights()
  end

  for vehicleID, remaining in pairs(pendingVehicles) do
    remaining = remaining - dtReal

    if remaining <= 0 then
      local vehicle = be:getObjectByID(vehicleID)

      if vehicle then
        local night = isNightTime()

        if night ~= nil then
          setVehicleHeadlights(vehicle, night)

          log("I", "autoHeadlights",
            "Vehicle " .. tostring(vehicleID) ..
            " headlights " .. (night and "ON" or "OFF"))
        end
      end

      pendingVehicles[vehicleID] = nil
    else
      pendingVehicles[vehicleID] = remaining
    end
  end
end

local function onExtensionLoaded()
  timer = CHECK_INTERVAL
  lastNightState = nil
  knownVehicles = {}
  pendingVehicles = {}

  log("I", "autoHeadlights", "Universal headlights loaded")
end

M.onUpdate = onUpdate
M.onExtensionLoaded = onExtensionLoaded

M.onVehicleSpawned = onVehicleSpawned
M.onVehicleResetted = onVehicleResetted
M.onVehicleReset = onVehicleReset
M.onVehicleDestroyed = onVehicleDestroyed

return M