load("RyLautoHeadlights")
setExtensionUnloadMode("RyLautoHeadlights", "manual")